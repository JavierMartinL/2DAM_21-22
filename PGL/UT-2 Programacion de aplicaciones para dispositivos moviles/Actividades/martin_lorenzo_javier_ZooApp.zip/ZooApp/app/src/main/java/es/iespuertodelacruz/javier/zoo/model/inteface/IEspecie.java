package es.iespuertodelacruz.javier.zoo.model.inteface;

public interface IEspecie extends IComun {

}
