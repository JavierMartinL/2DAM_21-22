package es.iespuertodelacruz.javier.zoo.model.inteface;

import android.content.ContentValues;

public interface IComun {
    int isValid();
    ContentValues toContentValues();
}
