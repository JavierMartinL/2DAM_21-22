package es.iespuertodelacruz.javier.zoo.activity.zoo;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import es.iespuertodelacruz.javier.zoo.R;

public class ZooActivity extends AppCompatActivity {

    public static final String EXTRA_ZOO_ID = "extra_zoo_id";

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zoo);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ZooFragment fragment = (ZooFragment)
                getSupportFragmentManager().findFragmentById(R.id.zoo_container);

        if (fragment == null) {
            fragment = ZooFragment.newInstance();
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.zoo_container, fragment)
                    .commit();
        }
    }
}
