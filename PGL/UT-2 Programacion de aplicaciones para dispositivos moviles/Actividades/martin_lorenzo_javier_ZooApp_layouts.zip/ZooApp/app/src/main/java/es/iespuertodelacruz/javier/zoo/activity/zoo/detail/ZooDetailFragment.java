package es.iespuertodelacruz.javier.zoo.activity.zoo.detail;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;

import es.iespuertodelacruz.javier.zoo.R;
import es.iespuertodelacruz.javier.zoo.activity.zoo.ZooActivity;
import es.iespuertodelacruz.javier.zoo.activity.zoo.ZooFragment;
import es.iespuertodelacruz.javier.zoo.activity.zoo.add.AddEditZooActivity;
import es.iespuertodelacruz.javier.zoo.model.helper.ZooDbHelper;
import es.iespuertodelacruz.javier.zoo.vo.Zoo;

public class ZooDetailFragment extends Fragment {
    private static final String ARG_ZOO_ID = "zooId";

    private String mZooId;

    private CollapsingToolbarLayout mCollapsingView;
    private ImageView mAvatar;
    private TextView mPhoneNumber;
    private TextView mSpecialty;
    private TextView mBio;

    private ZooDbHelper mZooDbHelper;


    public ZooDetailFragment() { }

    public static ZooDetailFragment newInstance(String zooId) {
        ZooDetailFragment fragment = new ZooDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ZOO_ID, zooId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mZooId = getArguments().getString(ARG_ZOO_ID);
        }

        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_zoo_detail, container, false);
        mCollapsingView = (CollapsingToolbarLayout) getActivity().findViewById(R.id.toolbar_layout);
        mAvatar = (ImageView) getActivity().findViewById(R.id.iv_avatar);
        mPhoneNumber = (TextView) root.findViewById(R.id.tv_phone_number);
        mSpecialty = (TextView) root.findViewById(R.id.tv_specialty);
        mBio = (TextView) root.findViewById(R.id.tv_bio);

        mZooDbHelper = new ZooDbHelper(getActivity());

        loadZoo();

        return root;
    }

    private void loadZoo() {
        new GetZooByIdTask().execute();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_edit:
                showEditScreen();
                break;
            case R.id.action_delete:
                new DeleteZooTask().execute();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ZooFragment.REQUEST_UPDATE_DELETE_ZOO) {
            if (resultCode == Activity.RESULT_OK) {
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        }
    }

    private void showZoo(Zoo zoo) {
        mCollapsingView.setTitle(zoo.getNombre());
        Glide.with(this)
                .load(Uri.parse("file:///android_asset/" + "zoo.jpg"))
                .centerCrop()
                .into(mAvatar);
        mPhoneNumber.setText(zoo.getCiudad());
        mSpecialty.setText(zoo.getPais());
        mBio.setText(zoo.getTamanio() + "");
    }

    private void showEditScreen() {
        Intent intent = new Intent(getActivity(), AddEditZooActivity.class);
        intent.putExtra(ZooActivity.EXTRA_ZOO_ID, mZooId);
        startActivityForResult(intent, ZooFragment.REQUEST_UPDATE_DELETE_ZOO);
    }

    private void showZoosScreen(boolean requery) {
        if (!requery) {
            showDeleteError();
        }
        getActivity().setResult(requery ? Activity.RESULT_OK : Activity.RESULT_CANCELED);
        getActivity().finish();
    }

    private void showLoadError() {
        Toast.makeText(getActivity(),
                "Error al cargar información", Toast.LENGTH_SHORT).show();
    }

    private void showDeleteError() {
        Toast.makeText(getActivity(),
                "Error al eliminar zoo", Toast.LENGTH_SHORT).show();
    }

    private class GetZooByIdTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return mZooDbHelper.getById(mZooId);
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            if (cursor != null && cursor.moveToLast()) {
                showZoo(new Zoo(cursor));
            } else {
                showLoadError();
            }
        }

    }

    private class DeleteZooTask extends AsyncTask<Void, Void, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            return  mZooDbHelper.delete(mZooId);
        }

        @Override
        protected void onPostExecute(Integer integer) {
            showZoosScreen(integer > 0);
        }

    }

}