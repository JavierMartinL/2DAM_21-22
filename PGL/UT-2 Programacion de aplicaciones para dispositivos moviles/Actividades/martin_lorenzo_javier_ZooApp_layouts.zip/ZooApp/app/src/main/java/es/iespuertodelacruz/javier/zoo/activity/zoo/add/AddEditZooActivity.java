package es.iespuertodelacruz.javier.zoo.activity.zoo.add;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import es.iespuertodelacruz.javier.zoo.R;
import es.iespuertodelacruz.javier.zoo.activity.zoo.ZooActivity;

public class AddEditZooActivity extends AppCompatActivity {
    public static final int REQUEST_ADD_ZOO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        String zooId = getIntent().getStringExtra(ZooActivity.EXTRA_ZOO_ID);

        setTitle(zooId == null ? "Añadir Zoo" : "Editar Zoo");

        AddEditZooFragment addEditZooFragment = (AddEditZooFragment)
                getSupportFragmentManager().findFragmentById(R.id.add_edit_zoo_container);
        if (addEditZooFragment == null) {
            addEditZooFragment = AddEditZooFragment.newInstance(zooId);
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.add_edit_zoo_container, addEditZooFragment)
                    .commit();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}