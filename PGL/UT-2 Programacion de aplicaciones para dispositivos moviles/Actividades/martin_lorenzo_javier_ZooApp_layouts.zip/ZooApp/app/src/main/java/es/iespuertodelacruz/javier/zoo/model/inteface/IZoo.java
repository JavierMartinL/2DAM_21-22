package es.iespuertodelacruz.javier.zoo.model.inteface;

public interface IZoo extends IComun {

}
