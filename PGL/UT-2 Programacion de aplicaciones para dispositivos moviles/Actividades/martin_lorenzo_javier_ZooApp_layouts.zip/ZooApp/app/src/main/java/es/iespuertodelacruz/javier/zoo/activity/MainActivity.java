package es.iespuertodelacruz.javier.zoo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import es.iespuertodelacruz.javier.zoo.R;
import es.iespuertodelacruz.javier.zoo.activity.zoo.ZooActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void pantallaZoo(View view) {
        Intent intent = new Intent(this, ZooActivity.class);
        startActivity(intent);
    }
}