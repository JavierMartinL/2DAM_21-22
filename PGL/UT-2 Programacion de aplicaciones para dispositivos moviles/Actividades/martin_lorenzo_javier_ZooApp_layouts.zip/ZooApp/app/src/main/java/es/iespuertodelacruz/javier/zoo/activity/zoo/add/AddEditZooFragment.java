package es.iespuertodelacruz.javier.zoo.activity.zoo.add;

import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import es.iespuertodelacruz.javier.zoo.R;
import es.iespuertodelacruz.javier.zoo.model.helper.ZooDbHelper;
import es.iespuertodelacruz.javier.zoo.vo.Zoo;

public class AddEditZooFragment extends Fragment {
    private static final String ARG_ZOO_ID = "arg_zoo_id";

    private String mZooId;

    private ZooDbHelper mZooDbHelper;

    private FloatingActionButton mSaveButton;
    private TextInputEditText mNombreField;
    private TextInputEditText mCiudadField;
    private TextInputEditText mPaisField;
    private TextInputEditText mTamanioField;
    private TextInputEditText mPresupuestoAnualField;
    private TextInputLayout mNombreLabel;
    private TextInputLayout mCiudadLabel;
    private TextInputLayout mPaisLabel;
    private TextInputLayout mTamanioLabel;
    private TextInputLayout mPresupuestoAnualLabel;


    public AddEditZooFragment() { }

    public static AddEditZooFragment newInstance(String zooId) {
        AddEditZooFragment fragment = new AddEditZooFragment();
        Bundle args = new Bundle();
        args.putString(ARG_ZOO_ID, zooId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mZooId = getArguments().getString(ARG_ZOO_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_add_edit_zoo, container, false);

        mSaveButton = (FloatingActionButton) getActivity().findViewById(R.id.fab);
        mNombreField = (TextInputEditText) root.findViewById(R.id.et_name);
        mCiudadField = (TextInputEditText) root.findViewById(R.id.et_ciudad);
        mPaisField = (TextInputEditText) root.findViewById(R.id.et_pais);
        mTamanioField = (TextInputEditText) root.findViewById(R.id.et_tamanio);
        mPresupuestoAnualField = (TextInputEditText) root.findViewById(R.id.et_presupuesto_anual);
        mNombreLabel = (TextInputLayout) root.findViewById(R.id.til_name);
        mCiudadLabel = (TextInputLayout) root.findViewById(R.id.til_ciudad);
        mPaisLabel = (TextInputLayout) root.findViewById(R.id.til_pais);
        mTamanioLabel = (TextInputLayout) root.findViewById(R.id.til_tamanio);
        mPresupuestoAnualLabel = (TextInputLayout) root.findViewById(R.id.til_presupuesto_anual);

        mSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addEditZoo();
            }
        });

        mZooDbHelper = new ZooDbHelper(getActivity());

        if (mZooId != null) {
            loadZoo();
        }

        return root;
    }

    private void loadZoo() {
        new GetZooByIdTask().execute();
    }

    private void addEditZoo() {
        boolean error = false;

        String nombre = mNombreField.getText().toString();
        String ciudad = mCiudadField.getText().toString();
        String pais = mPaisField.getText().toString();
        Integer tamanio = null;
        Integer presupuestoAnual = null;
        try {
            tamanio = Integer.parseInt(mTamanioField.getText().toString());
        } catch (Exception ex) {
            mTamanioLabel.setError("Debe ser un número");
        }

        try {
            presupuestoAnual = Integer.parseInt(mPresupuestoAnualField.getText().toString());
        } catch (Exception ex) {
            mPresupuestoAnualLabel.setError("Debe ser un número");
        }

        if (TextUtils.isEmpty(nombre)) {
            mNombreLabel.setError("Ingresa un valor");
            error = true;
        }

        if (TextUtils.isEmpty(ciudad)) {
            mCiudadLabel.setError("Ingresa un valor");
            error = true;
        }

        if (TextUtils.isEmpty(pais)) {
            mPaisLabel.setError("Ingresa un valor");
            error = true;
        }


        if (tamanio == null) {
            mTamanioLabel.setError("Ingresa un valor");
            error = true;
        }

        if (presupuestoAnual ==  null) {
            mPresupuestoAnualLabel.setError("Ingresa un valor");
            error = true;
        }

        if (error) {
            return;
        }

        Zoo zoo = new Zoo(nombre, ciudad, pais, tamanio, presupuestoAnual);

        new AddEditZooTask().execute(zoo);

    }

    private void showZooScreen(Boolean requery) {
        if (!requery) {
            showAddEditError();
            getActivity().setResult(Activity.RESULT_CANCELED);
        } else {
            getActivity().setResult(Activity.RESULT_OK);
        }

        getActivity().finish();
    }

    private void showAddEditError() {
        Toast.makeText(getActivity(),
                "Error al agregar nueva información", Toast.LENGTH_SHORT).show();
    }

    private void showZoo(Zoo zoo) {
        mNombreField.setText(zoo.getNombre());
        mCiudadField.setText(zoo.getCiudad());
        mPaisField.setText(zoo.getPais());
        mTamanioField.setText(zoo.getTamanio() + "");
        mPresupuestoAnualField.setText(zoo.getPresupuestoAnual() + "");
    }

    private void showLoadError() {
        Toast.makeText(getActivity(),
                "Error al editar zoo", Toast.LENGTH_SHORT).show();
    }

    private class GetZooByIdTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return mZooDbHelper.getById(mZooId);
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            if (cursor != null && cursor.moveToLast()) {
                showZoo(new Zoo(cursor));
            } else {
                showLoadError();
                getActivity().setResult(Activity.RESULT_CANCELED);
                getActivity().finish();
            }
        }

    }

    private class AddEditZooTask extends AsyncTask<Zoo, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Zoo... zoos) {
            if (mZooId != null) {
                return mZooDbHelper.update(zoos[0], mZooId) > 0;

            } else {
                return mZooDbHelper.save(zoos[0]) > 0;
            }

        }

        @Override
        protected void onPostExecute(Boolean result) {
            showZooScreen(result);
        }

    }

}
