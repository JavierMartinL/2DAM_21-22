package es.iespuertodelacruz.javier.zoo.model.helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import es.iespuertodelacruz.javier.zoo.model.contract.ZooContract;
import es.iespuertodelacruz.javier.zoo.vo.Zoo;

public class ZooDbHelper extends ComunDbHelper {

    public ZooDbHelper(Context context) {
        super(context);
    }

    /**
     * Metodo encargado en crear la tabla de la BBDD
     * @param sqLiteDatabase BBDD SqLite
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + ZooContract.ZooEntry.TABLE_NAME + " (" +
                ZooContract.ZooEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ZooContract.ZooEntry.NOMBRE + " TEXT NOT NULL," +
                ZooContract.ZooEntry.CIUDAD + " TEXT NOT NULL," +
                ZooContract.ZooEntry.PAIS + " TEXT NOT NULL," +
                ZooContract.ZooEntry.TAMANIO + " INTEGER NOT NULL," +
                ZooContract.ZooEntry.PRESUPUESTO_ANUAL + " REAL NOT NULL)");

        mockData(sqLiteDatabase);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ZooContract.ZooEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    private void mockData(SQLiteDatabase sqLiteDatabase) {
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
        mockZoo(sqLiteDatabase, new Zoo("Carlos Perez", "Abogado penalista",
                "300 200 1111", 1,
                123123));
    }

    public long mockZoo(SQLiteDatabase db, Zoo zoo) {
        return db.insert(
                ZooContract.ZooEntry.TABLE_NAME,
                null,
                zoo.toContentValues());
    }

    /**
     * Metodo que almacena la informacion en la BBDD
     * @param zoo Zoo de la BBDD
     * @return identificador con el resultado en el proceso de almacenar en la BBDD
     */
    public long save(Zoo zoo) {
        return super.save(ZooContract.ZooEntry.TABLE_NAME, zoo.toContentValues());
    }

    /**
     * Metodo que devuelve todos los elementos de la BBDD
     * @return Lista con los elementos
     */
    public Cursor getAll() {
        return getReadableDatabase()
                .query(
                        ZooContract.ZooEntry.TABLE_NAME,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null);
    }

    public Cursor getById(String zooId) {
        Cursor c = getReadableDatabase().query(
                ZooContract.ZooEntry.TABLE_NAME,
                null,
                ZooContract.ZooEntry._ID + " LIKE ?",
                new String[]{zooId},
                null,
                null,
                null);
        return c;
    }

    public int delete(String nombre) {
        return super.delete(ZooContract.ZooEntry.TABLE_NAME,ZooContract.ZooEntry.NOMBRE + " = ?", new String[]{nombre});
    }

    public int update(Zoo zoo, String nombre) {
        return super.update(ZooContract.ZooEntry.TABLE_NAME, zoo.toContentValues(), ZooContract.ZooEntry.NOMBRE + " = ?", new String[]{nombre});
    }
}
