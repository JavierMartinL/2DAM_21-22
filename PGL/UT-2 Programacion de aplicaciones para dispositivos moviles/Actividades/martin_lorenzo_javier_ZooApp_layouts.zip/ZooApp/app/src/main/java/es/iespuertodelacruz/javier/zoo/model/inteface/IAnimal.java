package es.iespuertodelacruz.javier.zoo.model.inteface;

public interface IAnimal extends IComun {

}
