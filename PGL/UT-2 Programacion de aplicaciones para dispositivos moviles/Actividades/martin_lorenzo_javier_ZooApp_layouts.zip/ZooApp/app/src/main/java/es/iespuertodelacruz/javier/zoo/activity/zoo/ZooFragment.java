package es.iespuertodelacruz.javier.zoo.activity.zoo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import es.iespuertodelacruz.javier.zoo.R;
import es.iespuertodelacruz.javier.zoo.activity.zoo.add.AddEditZooActivity;
import es.iespuertodelacruz.javier.zoo.activity.zoo.detail.ZooDetailActivity;
import es.iespuertodelacruz.javier.zoo.model.contract.ZooContract;
import es.iespuertodelacruz.javier.zoo.model.helper.ZooDbHelper;

public class ZooFragment extends Fragment {
    public static final int REQUEST_UPDATE_DELETE_ZOO = 2;

    private ZooDbHelper mZooDbHelper;

    private ListView mZooList;
    private ZooCursorAdapter mZooAdapter;
    private FloatingActionButton mAddButton;

    public ZooFragment() { }

    public static ZooFragment newInstance() {
        return new ZooFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {
        View root = inflater.inflate(R.layout.fragment_zoo, container, false);

        mZooList = (ListView) root.findViewById(R.id.zoo_list);
        mZooAdapter = new ZooCursorAdapter(getActivity(), null);
        mAddButton = (FloatingActionButton) getActivity().findViewById(R.id.fab);

        mZooList.setAdapter(mZooAdapter);

        mZooList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Cursor currentItem = (Cursor) mZooAdapter.getItem(i);
                @SuppressLint("Range") String currentLawyerId = currentItem.getString(
                        currentItem.getColumnIndex(ZooContract.ZooEntry._ID));

                showDetailScreen(currentLawyerId);
            }
        });
        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddScreen();
            }
        });

        getActivity().deleteDatabase(ZooDbHelper.DATABASE_NAME);

        mZooDbHelper = new ZooDbHelper(getActivity());

        loadZoos();

        return root;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Activity.RESULT_OK == resultCode) {
            switch (requestCode) {
                case AddEditZooActivity.REQUEST_ADD_ZOO:
                    showSuccessfullSavedMessage();
                    loadZoos();
                    break;
                case REQUEST_UPDATE_DELETE_ZOO:
                    loadZoos();
                    break;
            }
        }
    }

    private void loadZoos() {
        new ZoosLoadTask().execute();
    }

    private void showSuccessfullSavedMessage() {
        Toast.makeText(getActivity(),
                "Zoo guardado correctamente", Toast.LENGTH_SHORT).show();
    }

    private void showAddScreen() {
        Intent intent = new Intent(getActivity(), AddEditZooActivity.class);
        startActivityForResult(intent, AddEditZooActivity.REQUEST_ADD_ZOO);
    }

    private void showDetailScreen(String zooId) {
        Intent intent = new Intent(getActivity(), ZooDetailActivity.class);
        intent.putExtra(ZooActivity.EXTRA_ZOO_ID, zooId);
        startActivityForResult(intent, REQUEST_UPDATE_DELETE_ZOO);
    }

    private class ZoosLoadTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return mZooDbHelper.getAll();
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            if (cursor != null && cursor.getCount() > 0) {
                mZooAdapter.swapCursor(cursor);
            } else {
                // mostrar Vacio
            }
        }

    }
}
