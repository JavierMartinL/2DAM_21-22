<div align="justify">

# Ejemplos básicos en Android

<div align="center">
  <img src="https://i02.appmifile.com/images/2019/08/25/f78b7213-5fa0-4bd2-b704-74424d5dc0e6.png" width="400px" >
</div>

## Introducción

Repositorio dedicado a la creación de diferentes ejemplos en Android+/Java/Klotin).
 - [MVN+JAVA](mvc/MVC_JAVA.md)

Repositorio dedicado a ejemplos de Android

<div>  
