<div align="justify">

# ANDROID y MVC

<div align="center">
  <img src="https://www.simform.com/wp-content/uploads/2018/01/MVC-in-Android-Application-Development-.png" width="400px" >
</div>

## Introducción

<div>
