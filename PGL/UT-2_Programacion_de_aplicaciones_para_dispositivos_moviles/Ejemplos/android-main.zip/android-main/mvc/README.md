<div align="justify">

# Ejemplos básicos en Android y MVC

<div align="center">
  <img src="https://i02.appmifile.com/images/2019/08/25/f78b7213-5fa0-4bd2-b704-74424d5dc0e6.png" width="400px" >
</div>

## Introducción

<div>  
