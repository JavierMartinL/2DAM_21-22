package es.system.jpexposito.controller;

public interface ILoginController {
    void OnLogin(String email,String Password);
}
