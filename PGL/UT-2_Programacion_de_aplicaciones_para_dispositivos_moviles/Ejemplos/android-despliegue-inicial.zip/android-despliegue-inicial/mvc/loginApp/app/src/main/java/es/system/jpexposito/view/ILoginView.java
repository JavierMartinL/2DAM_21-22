package es.system.jpexposito.view;

public interface ILoginView {
    void OnLoginSuccess(String message);
    void OnLoginError(String message);
}
