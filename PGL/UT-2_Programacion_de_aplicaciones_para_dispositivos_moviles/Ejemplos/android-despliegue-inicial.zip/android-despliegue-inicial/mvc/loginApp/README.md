<div align="justify">

# Ejemplo Simple de MVC en JAVA

<div align="center">
  <img src="https://www.simform.com/wp-content/uploads/2018/01/MVC-in-Android-Application-Development-.png" width="400px" >
</div>

## Introducción

  El presente documento trata de describir de la forma más simple el modelo __MVC__ en una app en _Android_, con __JAVA__ como lenguaje de desarrollo.

  __MVC__ es un patrón de desarrollo o arquitectura que tiene como objetivo separar responsabilidades dentro de la _App_, con el objetivo de estructurar de forma correcta todas las partes implicadas en la App.

  Para comprender cuales son las responsabilidades y como hemos de

<div>  
