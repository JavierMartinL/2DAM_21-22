/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejprobadorexfinal;

import java.util.concurrent.Semaphore;

/**
 *
 * @author Asus
 */
public class Cliente implements Runnable {

    int idCliente;
    EjProbadorExFinal tienda;
    static int numeroPermisos = 5; // Numero de probadores.
    static Semaphore semaforo = new Semaphore(numeroPermisos);

    public Cliente(int id, EjProbadorExFinal shop) {
        this.idCliente = id;
        this.tienda = shop;
    }

    public void run() {
        try {
            semaforo.acquire();
            this.tienda.usarProbador(this.idCliente);
        } catch (InterruptedException E) {
        }
        semaforo.release();
    }
}
