/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejevaluablefactorial;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class EjEvaluableFactorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int resultado;
        System.out.println("Factorial del numero: ");
        int numero = scan.nextInt();
        int medio = numero/2;
        Calcular hilo1;
        hilo1 = new Calcular(1,medio,1);
        Calcular hilo2 = new Calcular(medio+1, numero,2);
        hilo1.start();
        hilo2.start();
        try { 
            hilo1.join();
            hilo2.join();
        } catch (InterruptedException ie) { ie.printStackTrace(); }
      
        resultado = hilo1.getResult()*hilo2.getResult();
        System.out.println(" Este es el resultado del cálculo factorial " + resultado);
    }
    
}
