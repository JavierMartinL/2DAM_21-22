/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejevaluablefactorial;

/**
 *
 * @author Asus
 */
public class Calcular extends Thread {
    private int inicio;
    private int fin;
    private int result;
    private int id;
    
    Calcular(int ini, int f,int id){
        this.inicio =ini;
        this.fin = f;
        this.id = id;
    }
    
    public int getResult (){
        return this. result;
    }
    
    public int getIde(){
        return this.id;
    }
    
    public void run(){
        int r = 1;
        for(int i=this.inicio; i<=this.fin; i++) {
            r = r*i;   
        }
        this.result = r;
    }
}
