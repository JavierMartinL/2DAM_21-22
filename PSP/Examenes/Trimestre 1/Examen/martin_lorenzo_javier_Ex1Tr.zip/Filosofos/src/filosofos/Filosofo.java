/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filosofos;

import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 *
 * @author Javier Martin Lorenzo <javiermartin.gara@gmail.com>
 */
public class Filosofo extends Thread {
    
    private final int idFilosofo;
    private final Semaphore[] palillosSemaphore;
    
    private final int palilloIzquierdo;
    private final int palilloDerecho;
    private final Random tiempoAleatorio = new Random();
    
    public Filosofo(int idFilosofo, Semaphore[] palillos_semaforo, int[] palillosFilosofo) {
        this.idFilosofo = idFilosofo;
        this.palillosSemaphore = palillos_semaforo;
        this.palilloIzquierdo = palillosFilosofo[0];
        this.palilloDerecho = palillosFilosofo[1];
    }
    
    protected void comer() {
        if (palillosSemaphore[palilloIzquierdo].tryAcquire()) {
            if (palillosSemaphore[palilloDerecho].tryAcquire()) {
                System.out.println("FILÓSOFO " + idFilosofo + " ESTÁ COMIENDO. "
                        + "Utiliza los palillos " + palilloIzquierdo + " y " + palilloDerecho);
                
                try {
                    sleep(tiempoAleatorio.nextInt(1000) + 500);
                } catch (InterruptedException ex) {
                    System.out.println("Error : " + ex.toString());
                }
                
                System.out.println("Filósofo " + idFilosofo + " ha terminado de comer. "
                        + "Libera los palillos " + palilloIzquierdo + " y " + palilloDerecho);
                
                palillosSemaphore[palilloDerecho].release();
            }
            palillosSemaphore[palilloIzquierdo].release();
        }
    }
    
    @Override
    public void run() {
        while (true) {
            try {
                Filosofo.sleep(tiempoAleatorio.nextInt(1000) + 100);
            } catch (InterruptedException ex) { 
                ex.printStackTrace();
            }
            comer();
        }
    }
}























/*
protected void pensar() {
        System.out.println("Filósofo " + idFilosofo + " está pensando.");
        try {
            Filosofo.sleep(tiempoAleatorio.nextInt(1000) + 100);
        } catch (InterruptedException ex) {
            System.out.println("Error en el método pensar(): " + ex.toString());
        }
    }
*/