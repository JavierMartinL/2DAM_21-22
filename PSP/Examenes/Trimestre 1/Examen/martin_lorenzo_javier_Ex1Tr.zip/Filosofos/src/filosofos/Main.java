/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filosofos;

import java.util.concurrent.Semaphore;

/**
 *
 * @author Javier Martin Lorenzo <javiermartin.gara@gmail.com>
 */
public class Main {

    final static int cantFilosofos = 5;
    final static int[][] listaPalillos = {
        {0, 4}, //Primer filosofo
        {1, 0}, //Segundo filosofo
        {2, 1}, //Tercer filosofo 
        {3, 2}, //Cuarto filosofo 
        {4, 3}  //Quinto filosofo 
    };
    final static Semaphore[] palillosSemaphore = new Semaphore[cantFilosofos];

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        for (int i = 0; i < cantFilosofos; i++) {
            palillosSemaphore[i] = new Semaphore(1);
        }
        
        for (int idFilosofo = 0; idFilosofo < cantFilosofos; idFilosofo++) {
            new Filosofo(idFilosofo, palillosSemaphore, listaPalillos[idFilosofo]).start();
        }
    }
    
}