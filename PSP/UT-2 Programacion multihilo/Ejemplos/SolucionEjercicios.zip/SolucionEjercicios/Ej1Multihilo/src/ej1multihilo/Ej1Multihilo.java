/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej1multihilo;
import java.util.*;

/**
 *
 * @author Asus
 */
public class Ej1Multihilo extends Thread{

    Scanner dato = new Scanner(System.in);
    String n, d;
    double h;
 
    public Ej1Multihilo(String nombre, String dia, double hora){
        n=nombre;
        d=dia;
        h=hora;
        System.out.println("Ingrese el nombre del empleado :");
        n = dato.next();
        System.out.println("Ingrese el dia :");
        d = dato.next();
        System.out.println("Ingrese la hora :");
        h = dato.nextDouble();
    }
    public void run(){
        if(h>8.00){
            System.out.println(n + " llego tarde el día " + d);
        }else{
            System.out.println(n + " llego temprano el día " + d);
        }
    }
    public static void main(String []args) throws InterruptedException{
        Thread usuario1 = new Ej1Multihilo(" "," ",0);
        usuario1.start();
        Thread.sleep(3000);
        Thread usuario2 = new Ej1Multihilo(" "," ",0);
        usuario2.start();
    }
}