/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej4multihilo;

/**
 *
 * @author Asus
 */
public class Ej4Multihilo extends Thread {
 static Ej4Multihilo liebre;
 static Ej4Multihilo conejo;
 static Ej4Multihilo tortuga; 
 String nombre;
 public Ej4Multihilo (int prioridad,String nombre){
    this.nombre=nombre;
    setPriority(prioridad);
 }
 public void run(){
    for(int c=1;c<=30;c++){
        System.out.print(c+"mt ");
        yield(); 
    }
    System.out.println("\n Llego a la meta " + nombre);
}
 
 public static void main(String []args) throws InterruptedException {
    conejo = new Ej4Multihilo(1," con ");
    liebre = new Ej4Multihilo(5," lie ");
    tortuga = new Ej4Multihilo(8," tor ");
    conejo.start();
    liebre.start();
    tortuga.start();
    conejo.join();
    liebre.join();
    tortuga.join();
 }
}