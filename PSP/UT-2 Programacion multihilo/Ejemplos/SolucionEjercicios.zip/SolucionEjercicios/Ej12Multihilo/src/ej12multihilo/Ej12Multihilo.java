/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej12multihilo;

/**
 *
 * @author Asus
 */

public class Ej12Multihilo extends Thread {

    String nombre;
    Saludo saludo;
    boolean Profesor;

    Ej12Multihilo(Saludo s, String n, boolean P) {
        nombre = n;
        saludo = s;
        Profesor = P;
    }

    public void run() {
        System.out.println(" ( " + nombre + " entra en clase ) ");
        if (Profesor) {
            saludo.respondersaludo();
        } else {
            saludo.saludarProfe(nombre);
        }
    }

    public static void main(String[] args) {
        Saludo hola = new Saludo();
        Ej12Multihilo Yazmina = new Ej12Multihilo(hola, "Yazmina", false);
        Ej12Multihilo Pepito = new Ej12Multihilo(hola, "Pepito", false);
        Ej12Multihilo Maria = new Ej12Multihilo(hola, "María", false);
        Ej12Multihilo Cesar = new Ej12Multihilo(hola, "Cesar", false);
        Ej12Multihilo Daniel = new Ej12Multihilo(hola, "Daniel", false);
        Ej12Multihilo Ruben = new Ej12Multihilo(hola, "Ruben", false);
        Ej12Multihilo Carlos = new Ej12Multihilo(hola, "Carlos", true);
        Yazmina.start();
        Pepito.start();
        Maria.start();
        Daniel.start();
        Cesar.start();
        Ruben.start();
        Carlos.start();
        try {
            Yazmina.join();
            Pepito.join();
            Maria.join();
            Daniel.join();
            Cesar.join();
            Ruben.join();
            Carlos.join();
        } catch (InterruptedException e) {
        }
    }
}    
    
class Saludo {

    synchronized void saludarProfe(String alumnos) {
        try {
            wait();
            System.out.println(alumnos + " --> Buenos dias Profesor !");
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }

    synchronized void respondersaludo() {
        System.out.println("Profesor --> Buenos dias");
        notifyAll();
    }

}

