/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej3multihilo;
import java.util.Scanner;
/**
 *
 * @author Asus
 */
public class Ej3Multihilo extends Thread{

    Scanner dato = new Scanner(System.in);
    String nombre;
    public void run(){
        System.out.println("Ingrese el nombre del atleta :");
        nombre = dato.next();
        for(int c=1;c<=30;c++){
            System.out.print(c + " km ");
        }
        try{
            sleep(3500); 
        }catch(InterruptedException e){
        }
        System.out.println("\n Llego a la meta " + nombre );
    }
    
    public static void main(String []args){ 
        Ej3Multihilo eje =new Ej3Multihilo();
        eje.start(); 
    }
}