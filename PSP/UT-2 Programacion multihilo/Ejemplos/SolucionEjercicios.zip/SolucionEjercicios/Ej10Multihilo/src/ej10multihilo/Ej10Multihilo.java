/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej10multihilo;
import java.util.*;
/**
 *
 * @author Asus
 */


public class Ej10Multihilo extends Thread {

    Scanner dato = new Scanner(System.in);
    int a;
    int b;

    public Ej10Multihilo() {

        System.out.println("Ingrese el primer numero ");
        a = dato.nextInt();
        System.out.println("Ingrese el segundo numero ");
        b = dato.nextInt();
    }

    String operacion = "";

    public void run() {
        System.out.println("Ingrese la operacion ");
        operacion = dato.next();
        switch (operacion) {
            case "suma":
                int suma = a + b;
                System.out.println("la suma de los numeros " + a + " " + " y " + " " + b + " es " + suma);
                break;
            case "resta":
                int resta = a - b;
                System.out.println("la resta de los numeros " + a + " " + " y " + " " + b + " es " + resta);

            case "multiplicacion":
                int multiplicacion = a * b;
                System.out.println("la multiplicacion de los numeros " + a + " " + " y " + " " + b + " es " + multiplicacion);
                break;
            case "division":
                int division = a / b;
                System.out.println("la division de los numeros " + a + " " + " y " + " " + b + " es " + division);
                break;
        }
    }

    public static void main(String[] args) {
        Ej10Multihilo oper = new Ej10Multihilo();
        oper.start();

    }
}
