/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej13multihilo;

/**
 *
 * @author Asus
 */
public class Ej13Multihilo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ejemplo transporte1 = new Ejemplo("coche");
        Ejemplo transporte2 = new Ejemplo("moto");
        Ejemplo transporte3 = new Ejemplo("guagua");
        transporte1.recorrido(15);
        transporte2.recorrido(12);
        transporte3.recorrido(18);
        transporte1.start();
        transporte2.start();
        transporte3.start();
    }
}
    

