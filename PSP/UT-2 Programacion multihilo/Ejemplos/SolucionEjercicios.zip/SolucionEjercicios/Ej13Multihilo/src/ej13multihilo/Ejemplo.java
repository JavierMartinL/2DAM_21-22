/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej13multihilo;

/**
 *
 * @author Asus
 */

public class Ejemplo extends Thread {

    int distancia;

    public Ejemplo(String transporte) {
        super(transporte);
    }

    public void run() {
        for (int a = 1; a <= distancia; a++) {
            System.out.println(getName() + " recorre " + a + " km");
        }
        System.out.println(" ");
    }

    public void recorrido(int metros) {
        this.distancia = metros;
    }
}
