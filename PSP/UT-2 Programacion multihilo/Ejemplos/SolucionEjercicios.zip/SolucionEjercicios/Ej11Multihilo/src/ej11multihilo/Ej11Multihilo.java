/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej11multihilo;

/**
 *
 * @author Asus
 */

public class Ej11Multihilo extends Thread {

    private String nombre;
    private String gato;

    public Ej11Multihilo(String nombre, String gato) {
        this.nombre = nombre;
        this.gato = gato;
    }

    public void run() {
        for (int a = 1; a < 2; a++) {
            System.out.println(nombre + " corre");
        }
        System.out.printf("%s \n", gato + " atrapa a " + nombre);
    }

    public static void main(String[] args) {
        String[] nombres = {"Papa pitufo", "pitufina", "Filósofo", "pintor", "Gruñón", "bromista",
            "Tímido", "Tontín", "Bonachón"};
        for (String nomb : nombres) {
            Ej11Multihilo e = new Ej11Multihilo(nomb, "Azrael");
            Thread t = new Thread(e);
            t.start();
        }
    }
}
