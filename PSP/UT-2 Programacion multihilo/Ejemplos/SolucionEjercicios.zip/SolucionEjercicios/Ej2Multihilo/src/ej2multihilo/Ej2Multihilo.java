/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej2multihilo;

/**
 *
 * @author Asus
 */
public class Ej2Multihilo extends Thread{

    public void run(){  
        for(int num =1; num<=20;num++){
            System.out.print(" " +num+" ");
            try {
                sleep (1500);
            }catch(InterruptedException e){
            }
        }
    }
    public static void main(String []args){
        Ej2Multihilo ejer = new Ej2Multihilo();
        ejer.start();
    }
}