/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej9multihilo;

/**
 *
 * @author Asus
 */

public class Ej9Multihilo extends Thread {

    public Ej9Multihilo(String cadena) {
        super(cadena);
    }

    public void run() {
        int conta = 1;
        while (conta <= 5) {
            System.out.println(conta + " " + getName());
            try {
                sleep((long) (Math.random() * 2000));
            } catch (InterruptedException e) {
                System.out.println("Ha ocurrido un error");
            }
            conta++;
        }
        System.out.println("Termino de las llamadas.......");
        System.out.println("Se realizaron " + conta + " llamadas");
    }

    public static void main(String[] args) {
        Ej9Multihilo iphone, nokia, motorola;
        iphone = new Ej9Multihilo("llamando a iphone");
        System.out.println(" REGITRO DE LLAMADAS");
        nokia = new Ej9Multihilo("llamando a nokia");
        motorola = new Ej9Multihilo("llamando a motorola");
        iphone.start();
        nokia.start();
        motorola.start();
        System.out.println("Inicio de llamadas....................");

    }
}
