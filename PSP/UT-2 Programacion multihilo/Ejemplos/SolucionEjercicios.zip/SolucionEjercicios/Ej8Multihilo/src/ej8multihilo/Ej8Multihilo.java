/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej8multihilo;
import java.util.*;
/**
 *
 * @author Asus
 */

public class Ej8Multihilo extends Thread {

    Scanner dato = new Scanner(System.in);

    public void run() {
        int n;
        int promedio = 0, nota = 1;
        int contador = 0;
        System.out.println("PROMEDIO DE NOTAS");
        while (nota < 6) {
            System.out.println("Ingrese nota " + nota + "°");
            n = dato.nextInt();
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
            }
            nota++;
            contador = contador + n;
            promedio = contador / nota;
        }
        System.out.println("El promedio es : " + promedio);
    }

    public static void main(String[] args) {
        Ej8Multihilo ejer9 = new Ej8Multihilo();
        ejer9.start();
    }
}
