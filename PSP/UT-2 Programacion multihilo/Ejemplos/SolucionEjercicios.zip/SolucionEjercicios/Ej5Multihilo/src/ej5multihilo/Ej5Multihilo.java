/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej5multihilo;

/**
 *
 * @author Asus
 */
public class Ej5Multihilo {

    public static void main(String []args){
        Pares eje1 = new Pares();
        eje1.start();
        Impares eje2 = new Impares();
        eje2.start();
    }

}