/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej5multihilo;

/**
 *
 * @author Asus
 */
public class Pares extends Thread{
    public void run(){
        int n;
        int contador=0;
        for (n=1;n<=10;n++){ 
            if (n % 2 == 0) {
                System.out.print(" "+n+"\n");
                contador=contador+n;
            } 
        }
        System.out.print("La suma de los pares es : "+contador + "\n");
        System.out.print(" ******************** \n");
    } 
}