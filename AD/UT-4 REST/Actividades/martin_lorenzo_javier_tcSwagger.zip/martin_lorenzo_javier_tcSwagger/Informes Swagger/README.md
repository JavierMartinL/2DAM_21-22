# Informe Swagger

<u>*Javier Martín Lorenzo*</u>

![img](https://lh3.googleusercontent.com/VPN0slWXYm1jHNxAuXMmsR1r8GX3LuGIr56M1P2Imr3p1gGef3AusgppinQuWg_VFSasv3pMhis3adXu4nDpPKWAJmGa86UJ-TAPmYwWWTdJqIjCsbnmeNPpiTzY1QorU_WjxUXI)

---
+ [Introducción](#introduccion)
+ [Instalación](#instalacion)
+ [Configuración](#configuracion)
+ [Ejecución](#ejecucion)
+ [Resultado](#resultado)
+ [Personalización](#personalizacion)
	* [Cabecera](#cabecera)
	* [Clases REST](#clasesRest)
	* [Clases Model](#clasesModel)
---

## Introducción <a name="introduccion"></a>

La documentación es esencial para cualquier proyecto, permite conocer y entender mejor las funciones o partes de él, especialmente en el mundo de la programación. A pesar de existir unos estándares mínimos que todos deberían seguir, documentar es necesario para explicar y ayudar a otras personas e incluso al mismo programador el contenido del código.

Sin embargo, documentar a mano se puede volver bastante tedioso, puede llevar varias horas documentar un proyecto entero, y esta debe cambiarse cada vez que se altera el código. Ahora bien, existen numerosas herramientas que permiten no solo actualizar la documentación de código, también ofrecen la posibilidad de visualizarla en una interfaz cómoda y amigable. Entre las herramientas más destacadas se encuentra Swagger.

Swagger es un framework multiplataforma que nos permite generar y visualizar documentación de APIs RESTful mediante diferentes etiquetas en el código, ofreciendo una interfaz simple pero muy bien diferenciada y con muchas opciones, como mostrar resultados de ejemplo o generar resultados de prueba personalizados.



## Instalación <a name="instalacion"></a>

Para esta demostración usaremos un proyecto API Spring sin versión de seguridad basado en institutos, con alumno, matricula y asignatura como clases principales.

Para instalar Swagger, es necesario en primer lugar agregar sus librerías (dependencias) en el archivo **pom.xml**. 

```xml
<dependency>
	<groupId>io.springfox</groupId>
	<artifactId>springfox-swagger2</artifactId>
	<version>2.9.2</version>
</dependency>

<dependency>
	<groupId>io.springfox</groupId>
	<artifactId>springfox-swagger-ui</artifactId>
	<version>2.9.2</version>
</dependency>
```

La primera dependencia (springfox-swagger2) analiza la estructura del proyecto y crea los metadatos para la documentación de la API, mientras que la segunda dependencia (springfox-swagger-ui) simplemente interpreta los datos y los muestra en una interfaz gráfica más cómoda para los usuarios. Podemos instalar ambas dependencias dentro del apartado dependencies:

![Dependencias de swagger](img/instalacion/dependencias_swagger.png)

Tras agregar las dependencias actualizamos el proyecto Maven. Se puede hacer desde el IDE Eclipse en: `botón derecho al proyecto -> Maven -> Update Project`.

## Configuración <a name="configuracion"></a>

En segundo lugar debemos crear un objeto Docket, que deberemos configurar para que Swagger recoja la información correcta del proyecto. Para ello debemos crear una clase Java de configuración de Swagger que tendrá las siguientes anotaciones y un método que crea el objeto Docket:

```java
@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket apiDocket() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.apis(RequestHandlerSelectors.basePackage("package de proyecto"))
				.paths(PathSelectors.any())
				.build();
	}
}
```

En el punto .apis debemos colocar el proyecto a indicar por lo que quedaría de la siguiente forma:

![Fichero de configuración de Swagger](img/configuracion/basica/swagger_config.png)

## Ejecución <a name="ejecucion"></a>

Una vez configurado debemos ejecutar el Servidor Spring. A partir de aquí pueden pasar dos cosas, que funcione todo perfecto a la primera (en ese caso ir directamente al apartado resultado) o que dé fallo al intentar arrancar el servidor, que es lo que se muestra aquí debajo: ![Error de arranque de Spring](img/configuracion/basica/error_configuracion.png)

Este error se produce debido a un conflicto al intentar usar al mismo tiempo Swagger y Hateoas. Para poder arreglar este error debemos agregar una segunda función a la clase de configuración de Swagger:

```java
@Bean
public LinkDiscoverers discoverers() {
    List<LinkDiscoverer> plugins = new ArrayList<>();
    plugins.add(new CollectionJsonLinkDiscoverer());
    return new LinkDiscoverers(SimplePluginRegistry.create(plugins));
}
```

Además, en el fichero de propiedades del proyecto Spring (application.properties) debemos agregar la siguiente línea:

```properties
spring.mvc.pathmatch.matching-strategy=ant-path-matcher
```

![Nueva propiedad del proyecto](img/configuracion/basica/properties.png)

## Resultado <a name="resultado"></a>

Tras ejecutar el servidor de Spring nos dirigimos a la siguiente ruta:

```http
http://localhost:8080/v2/api-docs
```

Si muestra el siguiente contenido o similar demuestra que Swagger se ha ejecutado correctamente, aunque el resultado inicial no sea lo suficientemente descriptivo.

![metadatos](img/interfaz/metadatos.png)

Estos son los metadatos generados por Swagger para la documentación, por lo que no están pensados para ser visualizados. Pero para esto instalamos también anteriormente **springfox-swagger-ui**, por lo que nos dirigimos al siguiente enlace:

```http
http://localhost:8080/swagger-ui.html
```

Y al abrirlo nos mostrará una página personalizada con la documentación de la API generada por defecto:

![interfaz básica](img/interfaz/vista_basica.png)

Cada apartado muestra las diferentes funciones CRUD de las Clases REST, en este caso alumno, asignatura y matrícula. Al acceder a alguna de las funciones, por ejemplo getAll de alumnos, nos mostrará un ejemplo de resultado en formato JSON:

![método básico](img/interfaz/metodo_basico.png)

Además la página nos dejará probar directamente dichos métodos en el botón “Try it out”:

![documentarParametrosVista](img/configuracion/avanzada/documentarParametrosVista.png)

## Personalización <a name="personalizacion"></a>

Una vez hemos comprobado como funciona la versión por defecto podemos modificar la cabecera de la documentación y añadir diversas etiquetas en el código para poder personalizar las clases y los métodos.

### Cabecera <a name="cabecera"></a>

Para personalizar la cabecera debemos volver al fichero de configuración de Swagger, crear un objeto de clase ApiInfo y agregarlo al método api() usado anteriormente:

```java
private ApiInfo apiInfo() {
	return new ApiInfo(
		“título”,
		“descripción”,
		“versión”,
		“términos de servicio”,
		“contacto”,
		“licencia”,
		“url de la licencia”
		“”);
}

@Bean
	public Docket apiDocket() {
		return new Docket(DocumentationType.SWAGGER_2)
			.select()
			.apis(RequestHandlerSelectors.basePackage("package de proyecto"))
			.paths(PathSelectors.any())
			.build()
			.apiInfo(apiInfo());
	}

```

![informacionApi](img/configuracion/avanzada/informacionApi.png)

Quedando de esta forma:

![informacionApiVista](img/configuracion/avanzada/informacionApiVista.png)

### Clases REST <a name="clasesRest"></a>

Las clases REST se pueden personalizar añadiendo un título personalizado:

```java
@Api ("titulo")
```

Pero también podemos añadirle una descripcion u otras etiquetas para aumentar la personalización:

```java
@Api (tags = "titulo",  description = "descripcion")
```

![documentarControlador](img/configuracion/avanzada/documentarControlador.png)

![documentarControladorVista](img/configuracion/avanzada/documentarControladorVista.png)

En el caso de los métodos que se pueden acceder en la api se pueden usar la etiqueta @ApiOperation:

```java
@ApiOperation ("valor")
```

```java
@ApiOperation (value = "valor", notes = "notas")
```

![documentarMetodos](img/configuracion/avanzada/documentarMetodos.png)

![documentarMetodosVista](img/configuracion/avanzada/documentarMetodosVista.png)

![metodosModificados](img/configuracion/avanzada/metodosModificados.png)

Dentro de los métodos también podemos personalizar los parámetros con @ApiParam:

```java
@ApiParam(
	name="nombre",
    type="String",
    value="Nombre",
    example="ar",
    required=false
)
```

![documentarParametros](img/configuracion/avanzada/documentarParametros.png)

Finalmente también podemos personalizar las diferentes respuestas que se puedan obtener con @ApiResponses y @ApiResponse:

```java
@ApiResponses(value = {
	@ApiResponse(code = 200, message = "OK", response = MatriculaDTO.class)})
```

![documentarRespuesta](img/configuracion/avanzada/documentarRespuesta.png)

![documentarRespuestaVista](img/configuracion/avanzada/documentarRespuestaVista.png)

### Clases Model <a name="clasesModel"></a>

No solo en las Clases API REST, también podemos personalizar las Clases Model que dan formato a los objetos Java que utilizamos en ellas, en este caso usamos @ApiModel:

```java
@ApiModel ("entidad")
```

Y en el caso de sus atributos usamos @ApiModelProperty:

```java
@ApiModelProperty ("atributo")
```

![documentarModeloCorto](img/configuracion/avanzada/documentarModelo.png)

![documentarModeloVista](img/configuracion/avanzada/documentarModeloVista.png)