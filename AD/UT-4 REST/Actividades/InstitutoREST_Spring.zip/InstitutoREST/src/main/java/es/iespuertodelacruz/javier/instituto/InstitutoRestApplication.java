package es.iespuertodelacruz.javier.instituto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstitutoRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstitutoRestApplication.class, args);
	}

}
