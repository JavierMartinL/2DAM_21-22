package es.iespuertodelacruz.javier.instituto.controller.v3;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.dto.AlumnoDTO;
import es.iespuertodelacruz.javier.instituto.dto.MatriculaAlumnoDTO;
import es.iespuertodelacruz.javier.instituto.entity.Alumno;
import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;
import es.iespuertodelacruz.javier.instituto.service.AlumnoService;
import es.iespuertodelacruz.javier.instituto.service.AsignaturaService;
import es.iespuertodelacruz.javier.instituto.service.MatriculaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping({"/api/v2/alumnos", "/api/v3/alumnos"})
@Api (
		tags = "Interfaz para la gestión de los Alumnos",
		description = "Proporcionar todas las peticiones relacionadas con los Alumnos y sus Matrículas (v2 / v3)"
		)
public class AlumnoRESTv2v3 {

	@Autowired
	private AlumnoService alumnoService;
	
	@Autowired
	private MatriculaService matriculaService;
	
	@Autowired
	private AsignaturaService asignaturaService;
	
	@GetMapping
	@ApiOperation(
			value = "Obtener todos los alumnos",
			notes = "Con esta petición podemos recoger todos los alumnos existes y "
					+ "a su vez ser filtrados por el nombre"
			)
	public List<AlumnoDTO> getAll(
			@ApiParam(
					name = "nombre",
					type = "String",
					value = "Nombre entero o parte de él",
					example = "ar",
					required = false
					)
			@RequestParam(name = "nombre", required = false) String nombre
			) {
		ArrayList<AlumnoDTO> alumnos = new ArrayList<AlumnoDTO>();
		
		nombre = nombre != null && !nombre.trim().equals("") ? "%" + nombre + "%" : null;
		
		if (nombre != null) {
			alumnoService
				.findByNombre(nombre)
				.forEach(a -> alumnos.add(new AlumnoDTO(a)));
		} else {
			alumnoService
				.findAll()
				.forEach(a -> alumnos.add(new AlumnoDTO(a)));
		}
		
		return alumnos;
	}
	
	@GetMapping("/{id}")
	@ApiOperation(
			value = "Obtener un alumno",
			notes = "Con esta petición recogemos los datos de un alumno mediante "
					+ "la introducción de su DNI"
			)
	public ResponseEntity<?> getById(
			@ApiParam(
					name = "id",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String id
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) 
			return ResponseEntity.ok().body(new AlumnoDTO(optAlumno.get()));
		else
			return ResponseEntity.notFound().build();
	}
	
	@GetMapping("/{id}/matriculas")
	@ApiOperation(
			value = "Obtener todas las matrículas de un alumno",
			notes = "Con esta petición recogeremos todas las matrículas que están "
					+ "relacionadas con el DNI del alumno"
			)
	public ResponseEntity<?> getAllMatriculas(
			@ApiParam(
					name = "id",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String id
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			return ResponseEntity.ok().body(optAlumno.get().getMatriculas());
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@GetMapping("/{idAlumno}/matriculas/{idMatricula}")
	@ApiOperation(
			value = "Obtener una matrícula de un alumno",
			notes = "Con esta petición recogeremos una matrícula que están "
					+ "relacionada con el DNI del alumno"
			)
	public ResponseEntity<?> getMatriculaById(
			@ApiParam(
					name = "idAlumno",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String idAlumno,
			@ApiParam(
					name = "idMatricula",
					type = "integer",
					value = "Identificador de la matrícula",
					example = "4",
					required = true
					)
			@PathVariable Integer idMatricula
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(idAlumno);
		if (optAlumno.isPresent()) {
			List<Matricula> matriculas = optAlumno.get().getMatriculas();
			for (Matricula matricula : matriculas) {
				if (matricula.getIdmatricula() == idMatricula) {
					return ResponseEntity.ok().body(new MatriculaAlumnoDTO(matricula));
				}
			}
			return ResponseEntity.notFound().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@PostMapping
	@ApiOperation(value = "Crear un nuevo alumno")
	public ResponseEntity<?> save(
			@ApiParam(
					name = "alumnoDTO",
					value = "Datos del Alumno",
					required = true
					)
			@RequestBody AlumnoDTO alumnoDTO
			) {
		try {
			Optional<Alumno> optAlumno = alumnoService.findById(alumnoDTO.getDni());
			if (!optAlumno.isPresent()) {
				Alumno alumno = new Alumno();
				alumno.setDni(alumnoDTO.getDni());
				alumno.setNombre(alumnoDTO.getNombre());
				alumno.setApellidos(alumnoDTO.getApellidos());
				alumno.setFechanacimiento(BigInteger.valueOf(alumnoDTO.getFechaNacimiento().getTime()));
				Alumno save = alumnoService.save(alumno);
				return ResponseEntity.status(HttpStatus.CREATED).body(new AlumnoDTO(save));
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Existe un Alumno con este DNI");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al crear el Alumno");
		}
	}
	
	@PostMapping("/{id}/matriculas")
	@ApiOperation(value = "Crear una nueva matrícula a un alumno")
	public ResponseEntity<?> saveMatricula(
			@ApiParam(
					name = "id",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String id,
			@ApiParam(
					name = "matriculaDTO",
					value = "Datos de la Matrícula",
					required = true
					)
			@RequestBody MatriculaAlumnoDTO matriculaDTO
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			try {
				Matricula matricula = new Matricula();
				matricula.setYear(matriculaDTO.getYear());
				matricula.setAlumno(optAlumno.get());
				List<Asignatura> asignaturas = new ArrayList<Asignatura>();
				
				if (matriculaDTO.getAsignaturas() != null) {
					for (Asignatura asignatura : matriculaDTO.getAsignaturas()) {
						Optional<Asignatura> optAsignatura = asignaturaService.findById(asignatura.getIdasignatura());
						if (optAsignatura.isPresent()) {
							asignaturas.add(optAsignatura.get());
						}
					}
				}
				
				matricula.setAsignaturas(asignaturas);
				Matricula save = matriculaService.save(matricula);
				return ResponseEntity.status(HttpStatus.CREATED).body(new MatriculaAlumnoDTO(save));
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al crear la Matricula");
			}
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@PutMapping("/{id}")
	@ApiOperation(value = "Modificar un alumno")
	public ResponseEntity<?> update(
			@ApiParam(
					name = "id",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String id,
			@ApiParam(
					name = "alumnoDTO",
					value = "Nuevos datos del Alumno",
					required = true
					)
			@RequestBody AlumnoDTO alumnoDTO
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			Alumno alumno = optAlumno.get();
			alumno.setNombre(alumnoDTO.getNombre());
			alumno.setApellidos(alumnoDTO.getApellidos());
			if (alumnoDTO.getFechaNacimiento() != null)
				alumno.setFechanacimiento(BigInteger.valueOf(alumnoDTO.getFechaNacimiento().getTime()));
			Alumno save = alumnoService.save(alumno);
			return ResponseEntity.ok(new AlumnoDTO(save));
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}
	
	@PutMapping("/{idAlumno}/matriculas/{idMatricula}")
	@ApiOperation(value = "Modificar la matrícula de un alumno")
	public ResponseEntity<?> updateMatricula(
			@ApiParam(
					name = "idAlumno",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String idAlumno,
			@ApiParam(
					name = "idMatricula",
					type = "integer",
					value = "Identificador de la matrícula",
					example = "4",
					required = true
					)
			@PathVariable Integer idMatricula,
			@ApiParam(
					name = "matriculaDTO",
					value = "Nuevos datos de la Matrícula",
					required = true
					)
			@RequestBody MatriculaAlumnoDTO matriculaDTO
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(idAlumno);
		if (optAlumno.isPresent()) {
			List<Matricula> matriculas = optAlumno.get().getMatriculas();
			for (Matricula matricula : matriculas) {
				if (matricula.getIdmatricula() == idMatricula) {
					if (matriculaDTO.getYear() != 0) {
						matricula.setYear(matriculaDTO.getYear());
					}
					List<Asignatura> asignaturas = new ArrayList<Asignatura>();
					
					if (matriculaDTO.getAsignaturas() != null) {
						for (Asignatura asignatura : matriculaDTO.getAsignaturas()) {
							Optional<Asignatura> optAsignatura = asignaturaService.findById(asignatura.getIdasignatura());
							if (optAsignatura.isPresent()) {
								asignaturas.add(optAsignatura.get());
							}
						}
					}
					
					matricula.setAsignaturas(asignaturas);
					Matricula save = matriculaService.save(matricula);
					return ResponseEntity.ok(new MatriculaAlumnoDTO(save));
				}
			}
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id de la matricula no existe");
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del alumno no existe");
		}
	}
	
	@DeleteMapping("/{id}")
	@ApiOperation(value = "Eliminar un alumno")
	public ResponseEntity<?> delete(
			@ApiParam(
					name = "id",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String id
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			try {
				alumnoService.deleteById(id);
				return ResponseEntity.ok("Alumno borrado");
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Este alumno esta relacionado con alguna matricula");
			}
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}
	
	@DeleteMapping("/{idAlumno}/matriculas/{idMatricula}")

	@ApiOperation(value = "Eliminar la matrícula de un alumno")
	public ResponseEntity<?> deleteMatricula(
			@ApiParam(
					name = "idAlumno",
					type = "String",
					value = "DNI del alumno",
					example = "12312312K",
					required = true
					)
			@PathVariable String idAlumno,
			@ApiParam(
					name = "idMatricula",
					type = "integer",
					value = "Identificador de la matrícula",
					example = "4",
					required = true
					)
			@PathVariable Integer idMatricula
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(idAlumno);
		if (optAlumno.isPresent()) {
			List<Matricula> matriculas = optAlumno.get().getMatriculas();
			for (Matricula matricula : matriculas) {
				if (matricula.getIdmatricula() == idMatricula) {
					matriculaService.deleteById(idMatricula);
					return ResponseEntity.ok("Matricula Eliminada");
				}
			}
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id de la matricula no existe");
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del alumno no existe");
		}
	}
		
}
