package es.iespuertodelacruz.javier.instituto.controller.v1;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.service.AsignaturaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Authorization;
import io.swagger.annotations.AuthorizationScope;

@RestController
@RequestMapping({"/api/v1/asignaturas", "/api/v2/asignaturas", "/api/v3/asignaturas"})
@Api (
		tags = "Interfaz para la consulta las Asignaturas", 
		description = "Proporcionar todas las peticiones GET relacionadas con las Asignaturas (v1 / v2 / v3)"
		)
public class AsignaturaRESTv1 {

	@Autowired
	private AsignaturaService asignaturaService;
	
	@GetMapping
	@ApiOperation(
			value = "Obtener todas las asignaturas",
			notes = "Con esta petición podemos recoger todas las asignaturas existes y a su "
					+ "vez ser filtrados por el nombre y/o por el curso"
			)
	public List<Asignatura> getAll(
			@ApiParam(
					name = "nombre",
					type = "String",
					value = "Nombre entero de la asignatura o parte de él",
					example = "PRO",
					required = false
					)
			@RequestParam(name = "nombre", required = false) String nombre,
			@ApiParam(
					name = "curso",
					type = "String",
					value = "Nombre del curso o parte de él",
					example = "DAM",
					required = false
					)
			@RequestParam(name = "curso", required = false) String curso
			) {
		ArrayList<Asignatura> asignaturas = new ArrayList<Asignatura>();
		
		nombre = nombre != null && !nombre.trim().equals("") ? nombre + "%" : null;
		curso = curso != null && !curso.trim().equals("") ?  "%" + curso + "%" : null;
		
		if (nombre != null && curso != null) {
			asignaturaService
				.findByNombreCurso(nombre, curso)
				.forEach(a -> asignaturas.add((Asignatura) a));
		} else if (nombre != null) {
			asignaturaService
				.findByNombre(nombre)
				.forEach(a -> asignaturas.add((Asignatura) a));
		} else if (curso != null) {
			asignaturaService
				.findByCurso(curso)
				.forEach(a -> asignaturas.add((Asignatura) a));
		} else {
			asignaturaService
				.findAll()
				.forEach(a -> asignaturas.add((Asignatura) a));
		}
		
		return asignaturas;
	}
	
	@GetMapping("/{id}")
	@ApiOperation(value = "Obtener una asignatura")
	public ResponseEntity<?> getById(
			@ApiParam(
					name = "id",
					type = "Integer",
					value = "Identificador de la asignatura",
					example = "1",
					required = true 
					)
			@PathVariable Integer id
			) {
		Optional<Asignatura> optAsignatura = asignaturaService.findById(id);
		
		if (optAsignatura.isPresent())
			return ResponseEntity.ok().body(optAsignatura);
		else 
			return ResponseEntity.notFound().build();
	}
	
}
