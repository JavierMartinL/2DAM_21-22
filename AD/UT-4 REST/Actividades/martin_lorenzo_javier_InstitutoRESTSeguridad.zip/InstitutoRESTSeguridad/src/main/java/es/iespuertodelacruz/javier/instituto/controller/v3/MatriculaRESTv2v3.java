package es.iespuertodelacruz.javier.instituto.controller.v3;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.dto.MatriculaDTO;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;
import es.iespuertodelacruz.javier.instituto.service.MatriculaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping({"/api/v2/matriculas", "/api/v3/matriculas"})
@Api (
		tags = "Interfaz para la consulta de las Matrículas",
		description = "Proporcionar peticiones GET relacionadas con las Matrículas (v2 / v3)"
		)
public class MatriculaRESTv2v3 {

	@Autowired
	private MatriculaService matriculaService;
	
	@GetMapping
	@ApiOperation(
			value = "Obtener todas las matrículas",
			notes = "Con esta petición podemos recoger todas las matrículas existes y a su vez "
					+ "ser filtrados por el año"
			)
	public List<Matricula> getAll(
			@ApiParam(
					name = "year",
					type = "integer",
					value = "Año de la matrícula",
					example = "2021",
					required = false
					)
			@RequestParam(name = "year", required = false) Integer year
			) {
		ArrayList<Matricula> matriculas = new ArrayList<Matricula>();
		
		if (year != null) {
			matriculaService
				.findByYear(year)
				.forEach(m -> matriculas.add((Matricula) m));
		} else {
			matriculaService
				.findAll()
				.forEach(m -> matriculas.add((Matricula) m));
		}
		
		return matriculas;
	}
	
	@GetMapping("/{id}")
	@ApiOperation(value = "Obtener una matrícula")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK", response = MatriculaDTO.class)
	})
	public ResponseEntity<?> findById(
			@ApiParam(
					name = "id",
					type = "integer",
					value = "Identificador de la matrícula",
					example = "2",
					required = true
					)
			@PathVariable Integer id
			) {
		Optional<Matricula> optMatricula = matriculaService.findById(id);
		
		if (optMatricula.isPresent()) {
			return ResponseEntity.ok().body(new MatriculaDTO(optMatricula.get()));
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
}
