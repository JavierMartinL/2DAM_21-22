package es.iespuertodelacruz.javier.instituto.dto;

import java.util.List;

import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;
import io.swagger.annotations.ApiModelProperty;

public class MatriculaDTO {

	@ApiModelProperty(
			  value = "Identificador de la Matrícula",
			  name = "idMatricula",
			  dataType = "Integer",
			  example = "12")
	private int idMatricula;
	
	@ApiModelProperty(
			  value = "Año de creación de la Matrícula",
			  name = "year",
			  dataType = "Integer",
			  example = "2022")
	private int year;
	
	@ApiModelProperty(
			  value = "Alumno relacionado con la Matrícula",
			  name = "alumno",
			  dataType = "AluumnoDTO",
			  example = "[ \"idasignatura\":1, \"idasignatura\":3]")
	private AlumnoDTO alumno;
	
	@ApiModelProperty(
			  value = "Todas las Asignaturas relacionadas con la Matrícula",
			  name = "asignaturas",
			  dataType = "List<Asignatura>")
	private List<Asignatura> asignaturas;
	
	public MatriculaDTO() { }
	
	public MatriculaDTO(Matricula matricula) {
		this.idMatricula = matricula.getIdmatricula();
		this.year = matricula.getYear();
		this.asignaturas = matricula.getAsignaturas();
		this.alumno = new AlumnoDTO(matricula.getAlumno());
	}

	public int getIdMatricula() {
		return idMatricula;
	}

	public void setIdMatricula(int idMatricula) {
		this.idMatricula = idMatricula;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public List<Asignatura> getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(List<Asignatura> asignaturas) {
		this.asignaturas = asignaturas;
	}

	public AlumnoDTO getAlumno() {
		return alumno;
	}

	public void setAlumno(AlumnoDTO alumno) {
		this.alumno = alumno;
	}
	
}
