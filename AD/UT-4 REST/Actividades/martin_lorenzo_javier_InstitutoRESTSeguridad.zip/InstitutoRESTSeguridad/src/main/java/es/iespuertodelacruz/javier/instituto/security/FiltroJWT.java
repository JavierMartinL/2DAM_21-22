package es.iespuertodelacruz.javier.instituto.security;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;

public class FiltroJWT extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
		GestorJWT gestorJWT = GestorJWT.getInstance();
		String token = null;
		
		try {
			token = request.getHeader(gestorJWT.AUTHORIZATIONHEADER)
					.replace(gestorJWT.BEARERPREFIX, "");
			
			Claims claims = gestorJWT.getClaims(token);
			
			if (claims.get(gestorJWT.ROLSCLAIMS) != null) {
				setUpSpringAuthentication(claims);
			} else {
				SecurityContextHolder.clearContext();
			}
			
		} catch (Exception ex) {
			SecurityContextHolder.clearContext();
		}
		
		filterChain.doFilter(request, response);
		
	}
	
	private void setUpSpringAuthentication(Claims claims) {
		
		GestorJWT gestorJWT = GestorJWT.getInstance();
		@SuppressWarnings("unchecked")
		List<String> authorities = (List) claims.get(gestorJWT.ROLSCLAIMS);
		
		UserDetails usuario = new User(claims.getSubject(), "1234", authorities.stream()
				.map(SimpleGrantedAuthority::new)
				.collect(Collectors.toList()));
		
		UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(usuario,  null, usuario.getAuthorities());
		
		SecurityContextHolder.getContext().setAuthentication(auth);
	}

}
