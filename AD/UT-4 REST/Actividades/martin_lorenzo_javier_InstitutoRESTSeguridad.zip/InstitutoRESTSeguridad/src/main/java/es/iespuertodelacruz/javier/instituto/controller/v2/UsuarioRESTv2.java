package es.iespuertodelacruz.javier.instituto.controller.v2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.dto.UsuarioDTOv2;
import es.iespuertodelacruz.javier.instituto.service.UsuarioService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/v2/usuarios")
@Api (
		tags = "Interfaz para la consulta de los Usuarios",
		description = "Muestra los nombres de los usuarios (v2)"
		)
public class UsuarioRESTv2 {

	@Autowired
	private UsuarioService usuarioService;
	
	@GetMapping
	@ApiOperation(
			value = "Obtener todos los usuarios",
			notes = "Solo devuelve los nombres"
			)
	public List<UsuarioDTOv2> getAll() {
		ArrayList<UsuarioDTOv2> usuarios = new ArrayList<UsuarioDTOv2>();
		
		usuarioService
			.findAll()
			.forEach(u -> usuarios.add(new UsuarioDTOv2(u)));
		
		return usuarios;
	}
	
}
