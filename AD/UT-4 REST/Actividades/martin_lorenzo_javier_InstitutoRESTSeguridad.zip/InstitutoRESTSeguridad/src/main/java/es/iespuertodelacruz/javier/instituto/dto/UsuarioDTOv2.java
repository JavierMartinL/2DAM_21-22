package es.iespuertodelacruz.javier.instituto.dto;

import es.iespuertodelacruz.javier.instituto.entity.Usuario;
import io.swagger.annotations.ApiModelProperty;

public class UsuarioDTOv2 {
	
	@ApiModelProperty(
			  value = "Nombre del Usuario",
			  name = "user",
			  dataType = "String",
			  example = "javier"
			  )
	private String user;

	public UsuarioDTOv2() { }
	
	public UsuarioDTOv2(Usuario usuario) {
		this.user = usuario.getUser();
	}
	
	public String getUser() {
		return user;
	}
	
	public void setUser(String user) {
		this.user = user;
	}
	
}
