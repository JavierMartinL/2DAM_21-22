package es.iespuertodelacruz.javier.instituto.controller.v3;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.dto.UsuarioDTOv3;
import es.iespuertodelacruz.javier.instituto.dto.UsuarioPut;
import es.iespuertodelacruz.javier.instituto.entity.Usuario;
import es.iespuertodelacruz.javier.instituto.service.UsuarioService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/api/v3/usuarios")
@Api (
		tags = "Interfaz para la gestión de los Usuarios",
		description = "Proporcionar todas las peticiones relacionadas con los Usuarios (v3)"
		)
public class UsuarioRESTv3 {

	@Autowired
	UsuarioService usuarioService;
	
	@GetMapping
	@ApiOperation(value = "Obtener todos los usuarios")
	public List<UsuarioDTOv3> getAll(
			@ApiParam(
					name = "rol",
					type = "String",
					example = "ROLE_USER",
					required = false
					)
			@RequestParam(name = "rol", required = false) String rol
			) {
		ArrayList<UsuarioDTOv3> usuarios = new ArrayList<UsuarioDTOv3>();
		
		rol = rol != null && !rol.trim().equals("") ? rol : null;
		
		if (rol != null) {
			usuarioService
				.findByRol(rol)
				.forEach(u -> usuarios.add(new UsuarioDTOv3(u)));
		} else {
			usuarioService
				.findAll()
				.forEach(u -> usuarios.add(new UsuarioDTOv3(u)));
		}
		
		return usuarios;
	}
	
	@GetMapping("/{user}")
	@ApiOperation(value = "Obtener un Usuario")
	public ResponseEntity<?> findByUser(
			@ApiParam(
					name = "id",
					type = "String",
					value = "Nombre del Usuario",
					example = "admin",
					required = true
					)
			@PathVariable("user") String id
			) {
		Optional<Usuario> usuario = usuarioService.findById(id);
		
		if (usuario.isPresent()) {
			return ResponseEntity.ok().body(new UsuarioDTOv3(usuario.get()));
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("El usuario no existe");
		}
		
	}
	
	@PostMapping
	@ApiOperation(value = "Crear un nuevo Usuario")
	public ResponseEntity<?> save(
			@ApiParam(
					name = "user",
					value = "Datos del Usuario",
					required = true
					)
			@RequestBody Usuario user
			) {
		
		Optional<Usuario> usuarioCreado = usuarioService.findById(user.getUser());
		
		if (usuarioCreado.isEmpty()) {
			try {
				
				user.setPassword(cifrarPassword(user.getPassword()));
				
				if (user.getPassword() != null) {
					Usuario usuario = usuarioService.save(user);
					return ResponseEntity.status(HttpStatus.CREATED).body(new UsuarioDTOv3(usuario));
				} else {
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error con la contraseña");
				}
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al crear el Usuario");
			}
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Existe un usuario con este Nombre");
		}
	}
	
	@PutMapping("/{user}")
	@ApiOperation(value = "Modificar un Usuario")
	public ResponseEntity<?> update(
			@ApiParam(
					name = "id",
					type = "String",
					value = "Nombre del Usuario",
					example = "javier",
					required = true
					)
			@PathVariable("user") String id,
			@ApiParam(
					name = "user",
					value = "Datos del Usuario",
					required = true
					)
			@RequestBody UsuarioPut user
			) {
		Optional<Usuario> optUsuario = usuarioService.findById(id);
		
		if (optUsuario.isPresent()) {
			Usuario usuario = optUsuario.get();
			usuario.setPassword(cifrarPassword(user.getPassword()));
			usuario.setRol(user.getRol());
			
			if (usuario.getPassword() != null) {
				usuario = usuarioService.save(usuario);
				return ResponseEntity.ok(new UsuarioDTOv3(usuario));
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error con la contraseña");
			}
			
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("El usuario no existe");
		}

	}
	
	@DeleteMapping("/{user}")
	@ApiOperation(value = "Eliminar un usuario")
	public ResponseEntity<?> delete(
			@ApiParam(
					name = "id",
					type = "String",
					value = "Nombre del Usuario",
					example = "javier",
					required = true
					)
			@PathVariable("user") String id
			) {
		Optional<Usuario> optUsuario = usuarioService.findById(id);
		
		if (optUsuario.isPresent()) {
			try {
				usuarioService.deleteById(id);
				return ResponseEntity.ok("Usuario borrado");
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al eliminar el Usuario");
			}
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("El usuario no existe");
		}
	}
	
	private String cifrarPassword(String password) {
		
		if (password != null && !password.trim().equals(""))
			return BCrypt.hashpw(password, BCrypt.gensalt(10));
		else
			return null;
	}
	
}
