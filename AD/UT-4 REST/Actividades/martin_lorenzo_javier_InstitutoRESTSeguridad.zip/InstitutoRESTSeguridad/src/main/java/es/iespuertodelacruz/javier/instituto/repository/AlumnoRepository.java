package es.iespuertodelacruz.javier.instituto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import es.iespuertodelacruz.javier.instituto.entity.Alumno;

public interface AlumnoRepository extends JpaRepository<Alumno, String> {
	
	@Query("SELECT a FROM Alumno a where a.nombre LIKE :nombre")
	List<Alumno> findByNombre(@Param("nombre") String strNombre);
	
}
