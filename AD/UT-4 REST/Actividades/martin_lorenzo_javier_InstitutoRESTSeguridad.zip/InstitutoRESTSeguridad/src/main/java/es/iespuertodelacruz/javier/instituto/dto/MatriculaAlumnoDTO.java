package es.iespuertodelacruz.javier.instituto.dto;

import java.util.List;

import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "MatriculaAlumno")
public class MatriculaAlumnoDTO {
	
	@ApiModelProperty(
			  value = "Identificador de la Matrícula",
			  name = "idMatricula",
			  dataType = "Integer",
			  hidden = true)
	private int idMatricula;
	@ApiModelProperty(
			  value = "Año",
			  name = "year",
			  dataType = "Integer",
			  example = "2022")
	private int year;
	@ApiModelProperty(
			  value = "Todas las Asignaturas relacionadas con la Matrícula",
			  name = "asignaturas",
			  dataType = "List<Asignatura>",
			  example = "[ \"idasignatura\":1, \"idasignatura\":3]")
	private List<Asignatura> asignaturas;
	
	public MatriculaAlumnoDTO() { }
	
	public MatriculaAlumnoDTO(Matricula matricula) {
		this.idMatricula = matricula.getIdmatricula();
		this.year = matricula.getYear();
		this.asignaturas = matricula.getAsignaturas();
	}

	public int getIdMatricula() {
		return idMatricula;
	}

	public void setIdMatricula(int idMatricula) {
		this.idMatricula = idMatricula;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public List<Asignatura> getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(List<Asignatura> asignaturas) {
		this.asignaturas = asignaturas;
	}
	
}
