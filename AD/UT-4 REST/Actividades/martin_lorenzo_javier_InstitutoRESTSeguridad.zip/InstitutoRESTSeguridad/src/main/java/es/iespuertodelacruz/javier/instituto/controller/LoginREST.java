package es.iespuertodelacruz.javier.instituto.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.dto.UsuarioLogin;
import es.iespuertodelacruz.javier.instituto.entity.Usuario;
import es.iespuertodelacruz.javier.instituto.security.GestorJWT;
import es.iespuertodelacruz.javier.instituto.service.UsuarioService;
import io.swagger.annotations.Api;

@RestController
@Api (
		tags = "Interfaz para el Login de Usuarios",
		description = "Login de Usuarios",
		position = 0
		)
public class LoginREST {

	@Autowired
	UsuarioService usuarioService;
	
	@PostMapping(path = "/api/login", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> login(@RequestParam("user") String usuario, @RequestParam("password") String password) {
		
		String token = getJWTToken(usuario, password);
		
		if (token != null)
			return ResponseEntity.ok(token);
		else 
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("usuario/contraseña erróneos");
		
	}
	
	@PostMapping(path = "/api/login", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> login (@RequestBody UsuarioLogin usuarioLogin) {
		
		String token = getJWTToken(usuarioLogin.getUser(), usuarioLogin.getPassword());
		
		if (token != null)
			return ResponseEntity.ok(token);
		else
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("usuario/contraseña erróneos");
		
	}
	
	private String getJWTToken(String user, String passwordString) {
		
		String respuesta = null;
		GestorJWT gestorJWT = GestorJWT.getInstance();
		Optional<Usuario> usuario = usuarioService.findById(user);
		
		String passwordHash = "";
		boolean autenticado = false;
		
		if (usuario.isPresent()) {
			passwordHash = usuario.get().getPassword();
			autenticado = BCrypt.checkpw(passwordString, passwordHash);
		}
		
		if (autenticado) {
			String rol = usuario.get().getRol();
			List<String> roles = new ArrayList<String>();
			roles.add(rol);
			
			int duracionMinutos = 600;
			
			String token = gestorJWT.generarToken(user, roles, duracionMinutos);
			
			respuesta = gestorJWT.BEARERPREFIX + token;
			
		}
		
		return respuesta;
		
	}
	
}
