package es.iespuertodelacruz.javier.instituto.dto;

import es.iespuertodelacruz.javier.instituto.entity.Usuario;
import io.swagger.annotations.ApiModelProperty;

public class UsuarioDTOv3 {

	@ApiModelProperty(
			  value = "Nombre del Usuario",
			  name = "user",
			  dataType = "String",
			  example = "javier"
			  )
	private String user;
	
	@ApiModelProperty(
			  value = "Rol del Usuario",
			  name = "rol",
			  dataType = "String",
			  example = "ROLE_USER")
	private String rol;

	public UsuarioDTOv3() { }
	
	public UsuarioDTOv3(Usuario usuario) {
		this.user = usuario.getUser();
		this.rol = usuario.getRol();
	}
	
	public String getUser() {
		return user;
	}
	
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getRol() {
		return rol;
	}
	
	public void setRol(String rol) {
		this.rol = rol;
	}
	
}
