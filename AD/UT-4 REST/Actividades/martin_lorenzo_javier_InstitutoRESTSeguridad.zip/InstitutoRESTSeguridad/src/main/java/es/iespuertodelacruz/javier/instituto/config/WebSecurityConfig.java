package es.iespuertodelacruz.javier.instituto.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsUtils;

import es.iespuertodelacruz.javier.instituto.security.FiltroJWT;

@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	public void configure(WebSecurity webSecurity) throws Exception {
		webSecurity
			.ignoring()
			.antMatchers(HttpMethod.POST, "/api/login")
			.antMatchers(
					"/api/v1/**",
					"/v2/api-docs",
					"/swagger-ui.html",
					"/swagger-ui/*",
					"/swagger-resources/**",
					"/configuration/security",
					"/configuration/ui",
					"/webjars/**");
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.csrf().disable()
			.addFilterBefore(new FiltroJWT(), UsernamePasswordAuthenticationFilter.class)
			.authorizeRequests()
			.requestMatchers(CorsUtils::isCorsRequest).permitAll()
			.antMatchers(HttpMethod.OPTIONS, "**").permitAll()
			.antMatchers("/api/v3/**").hasRole("ADMIN")
			.anyRequest().authenticated();
	}
	
}
