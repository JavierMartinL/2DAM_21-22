package es.iespuertodelacruz.javier.instituto.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;


/**
 * The persistent class for the matriculas database table.
 * 
 */
@Entity
@Table(name="matriculas")
@NamedQuery(name="Matricula.findAll", query="SELECT m FROM Matricula m")
public class Matricula implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@ApiModelProperty(
			  value = "Identificador de la Matrícula",
			  name = "idmatricula",
			  dataType = "Integer",
			  hidden = true
			  )
	private int idmatricula;

	@ApiModelProperty(
			  value = "Año de creación de la Matrícula",
			  name = "year",
			  dataType = "Integer",
			  example = "2022"
			  )
	private int year;

	//bi-directional many-to-one association to Alumno
	@ManyToOne
	@JoinColumn(name="dni")
	@JsonIgnore
	private Alumno alumno;
	
	@ManyToMany
	@JoinTable(name="asignatura_matricula",
			joinColumns = @JoinColumn(name="idmatricula"),
			inverseJoinColumns = @JoinColumn(name="idasignatura")
			)
	@JsonIgnore
	private List<Asignatura> asignaturas;

	public Matricula() {
	}

	public int getIdmatricula() {
		return this.idmatricula;
	}

	public void setIdmatricula(int idmatricula) {
		this.idmatricula = idmatricula;
	}

	public int getYear() {
		return this.year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Alumno getAlumno() {
		return this.alumno;
	}

	public void setAlumno(Alumno alumno) {
		this.alumno = alumno;
	}

	public List<Asignatura> getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(List<Asignatura> asignaturas) {
		this.asignaturas = asignaturas;
	}

}