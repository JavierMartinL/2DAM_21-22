package es.iespuertodelacruz.javier.instituto.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.repository.AsignaturaRepository;

@Service
public class AsignaturaService implements GenericService<Asignatura, Integer> {

	@Autowired
	private AsignaturaRepository asignaturaRepository;
	
	@Override
	@Transactional(readOnly = true)
	public Iterable<Asignatura> findAll() {
		return asignaturaRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<Asignatura> findAll(Pageable pageable) {
		return asignaturaRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Asignatura> findById(Integer id) {
		return asignaturaRepository.findById(id);
	}
	
	@Transactional(readOnly=true)
	public List<Asignatura> findByNombre(String nombre) {
		return asignaturaRepository.findByNombre(nombre);
	}
	
	@Transactional(readOnly=true)
	public List<Asignatura> findByCurso(String curso) {
		return asignaturaRepository.findByCurso(curso);
	}
	
	@Transactional(readOnly=true)
	public List<Asignatura> findByNombreCurso(String nombre, String curso) {
		return asignaturaRepository.findByNombreCurso(nombre, curso);
	}

	@Override
	@Transactional
	public Asignatura save(Asignatura objeto) {
		return asignaturaRepository.save(objeto);
	}

	@Override
	@Transactional
	public void delete(Asignatura objeto) {
		asignaturaRepository.delete(objeto);
	}

	@Override
	@Transactional
	public void deleteById(Integer id) {
		asignaturaRepository.deleteById(id);
	}

}
