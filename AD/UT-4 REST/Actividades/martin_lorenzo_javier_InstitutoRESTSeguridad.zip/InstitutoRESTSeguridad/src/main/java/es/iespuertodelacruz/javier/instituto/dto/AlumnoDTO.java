package es.iespuertodelacruz.javier.instituto.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import es.iespuertodelacruz.javier.instituto.entity.Alumno;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "Alumno")
public class AlumnoDTO {

	@ApiModelProperty(
			  value = "DNI",
			  name = "dni",
			  dataType = "String",
			  example = "12345678A")
	private String dni;
	@ApiModelProperty(
			  value = "Nombre",
			  name = "nombre",
			  dataType = "String",
			  example = "Paco")
	private String nombre;
	@ApiModelProperty(
			  value = "Apellidos",
			  name = "apellidos",
			  dataType = "String",
			  example = "Mendez")
	private String apellidos;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@ApiModelProperty(
			  value = "Fecha de Nacimiento",
			  name = "fechaNacimiento",
			  dataType = "String",
			  example = "2000-04-12")
	private Date fechaNacimiento;
	
	public AlumnoDTO() { }
	
	public AlumnoDTO(Alumno alumno) {
		this.dni = alumno.getDni();
		this.nombre = alumno.getNombre();
		this.apellidos = alumno.getApellidos();
		if (alumno.getFechanacimiento() != null) {
			this.fechaNacimiento = new Date(alumno.getFechanacimiento().longValue());
		} else {
			this.fechaNacimiento = null;
		}
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
}
