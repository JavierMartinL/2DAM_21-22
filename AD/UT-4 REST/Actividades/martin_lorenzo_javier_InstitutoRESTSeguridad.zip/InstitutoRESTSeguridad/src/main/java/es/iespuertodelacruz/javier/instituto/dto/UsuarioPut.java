package es.iespuertodelacruz.javier.instituto.dto;

import es.iespuertodelacruz.javier.instituto.entity.Usuario;
import io.swagger.annotations.ApiModelProperty;

public class UsuarioPut {

	@ApiModelProperty(
			  value = "Contraseña del Usuario",
			  name = "password",
			  dataType = "String"
			  )
	private String password;
	
	@ApiModelProperty(
			  value = "Rol del Usuario",
			  name = "rol",
			  dataType = "String",
			  example = "ROLE_USER")
	private String rol;

	public UsuarioPut() { }
	
	public UsuarioPut(Usuario usuario) {
		this.password = usuario.getPassword();
		this.rol = usuario.getRol();
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getRol() {
		return rol;
	}
	
	public void setRol(String rol) {
		this.rol = rol;
	}
}
