package es.iespuertodelacruz.javier.instituto.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.iespuertodelacruz.javier.instituto.entity.Usuario;
import es.iespuertodelacruz.javier.instituto.repository.UsuarioRepository;

@Service
public class UsuarioService implements GenericService<Usuario, String> {

	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Override
	@Transactional(readOnly = true)
	public Iterable<Usuario> findAll() {
		return usuarioRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<Usuario> findAll(Pageable pageable) {
		return usuarioRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Usuario> findById(String id) {
		return usuarioRepository.findById(id);
	}
	
	@Transactional(readOnly = true)
	public List<Usuario> findByRol(String rol) {
		return usuarioRepository.findByRol(rol);
	}

	@Override
	@Transactional
	public Usuario save(Usuario objeto) {
		return usuarioRepository.save(objeto);
	}

	@Override
	@Transactional
	public void delete(Usuario objeto) {
		usuarioRepository.delete(objeto);
	}

	@Override
	@Transactional
	public void deleteById(String id) {
		usuarioRepository.deleteById(id);
	}

}
