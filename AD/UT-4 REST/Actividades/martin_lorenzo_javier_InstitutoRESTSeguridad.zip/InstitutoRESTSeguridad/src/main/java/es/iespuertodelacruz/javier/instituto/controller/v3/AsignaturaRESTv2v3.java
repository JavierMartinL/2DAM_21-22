package es.iespuertodelacruz.javier.instituto.controller.v3;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.service.AsignaturaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping({"/api/v2/asignaturas", "/api/v3/asignaturas"})
@Api (
		tags = "Interfaz para la gestión de las Asignaturas",
		description = "Proporcionar todas las peticiones POST/PUT/DELETE relacionadas con las Asignaturas (v2 / v3)"
		)
public class AsignaturaRESTv2v3 {

	@Autowired
	private AsignaturaService asignaturaService;
	
	@PostMapping
	@ApiOperation(value = "Crear una nueva asignatura")
	public ResponseEntity<?> save(
			@ApiParam(
					name = "asignatura",
					value = "Datos de la Asignatura",
					required = true
					)
			@RequestBody Asignatura asignatura
			){
		try {
			Asignatura save = asignaturaService.save(asignatura);
			return ResponseEntity.status(HttpStatus.CREATED).body(save);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al crear la Asignatura");
		}
	}
	
	@PutMapping("/{id}")
	@ApiOperation(value = "Modificar una asignatura")
	public ResponseEntity<?> update(
			@ApiParam(
					name = "id",
					type = "Integer",
					value = "Identificador de la asignatura",
					example = "1",
					required = true 
					)
			@PathVariable Integer id,
			@ApiParam(
					name = "updateAsignatura",
					value = "Nuevos datos de la Asignatura",
					required = true
					)
			@RequestBody Asignatura updateAsignatura
			) {
		Optional<Asignatura> optAsignatura = asignaturaService.findById(id);
		if (optAsignatura.isPresent()) {
			Asignatura asignatura = optAsignatura.get();
			asignatura.setNombre(updateAsignatura.getNombre());
			asignatura.setCurso(updateAsignatura.getCurso());
			return ResponseEntity.ok(asignaturaService.save(asignatura));
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}
	
	@DeleteMapping("/{id}")
	@ApiOperation(value = "Eliminar una asignatura")
	public ResponseEntity<?> delete(
			@ApiParam(
					name = "id",
					type = "Integer",
					value = "Identificador de la asignatura",
					example = "1",
					required = true 
					)
			@PathVariable Integer id
			){
		Optional<Asignatura> optAsignatura = asignaturaService.findById(id);
		if(optAsignatura.isPresent()) {
			try {
				asignaturaService.deleteById(id);
				return ResponseEntity.ok("Asignatura borrada");
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Esta asignatura esta relacionada con alguna matricula");
			}
		}else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}
	
}
