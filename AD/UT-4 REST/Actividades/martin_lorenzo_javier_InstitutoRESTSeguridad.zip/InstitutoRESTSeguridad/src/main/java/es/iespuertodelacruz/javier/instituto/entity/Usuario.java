package es.iespuertodelacruz.javier.instituto.entity;

import java.io.Serializable;
import javax.persistence.*;

import io.swagger.annotations.ApiModelProperty;


/**
 * The persistent class for the usuarios database table.
 * 
 */
@Entity
@Table(name="usuarios")
@NamedQuery(name="Usuario.findAll", query="SELECT u FROM Usuario u")
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@ApiModelProperty(
			  value = "Nombre del Usuario",
			  name = "user",
			  dataType = "String",
			  example = "javier"
			  )
	private String user;

	@ApiModelProperty(
			  value = "Contraseña del Usuario",
			  name = "password",
			  dataType = "String",
			  example = "javier"
			  )
	private String password;

	@ApiModelProperty(
			  value = "Rol del Usuario",
			  name = "rol",
			  dataType = "String",
			  example = "ROLE_USER")
	private String rol;

	public Usuario() {
	}

	public String getUser() {
		return this.user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRol() {
		return this.rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

}