package es.iespuertodelacruz.javier.instituto.dto;

import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModelProperty;

@Component
public class UsuarioLogin {
	
	@ApiModelProperty(
			  value = "Nombre del Usuario",
			  name = "user",
			  dataType = "String",
			  example = "javier"
			  )
	private String user;
	
	@ApiModelProperty(
			  value = "Contraseña del Usuario",
			  name = "password",
			  dataType = "String",
			  example = "javier"
			  )
	private String password;
	
	public UsuarioLogin() { }
	
	public String getUser() {
		return user;
	}
	
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password ) {
		this.password = password;
	}
}
