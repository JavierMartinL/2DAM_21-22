package es.iespuertodelacruz.javier.instituto.dto;

import java.util.List;

import es.iespuertodelacruz.javier.instituto.entity.Alumno;
import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;

public class MatriculaDTO {

	private int idMatricula;
	private int year;
	private AlumnoDTO alumno;
	private List<Asignatura> asignaturas;
	
	public MatriculaDTO() { }
	
	public MatriculaDTO(Matricula matricula) {
		this.idMatricula = matricula.getIdmatricula();
		this.year = matricula.getYear();
		this.asignaturas = matricula.getAsignaturas();
		this.alumno = new AlumnoDTO(matricula.getAlumno());
	}

	public int getIdMatricula() {
		return idMatricula;
	}

	public void setIdMatricula(int idMatricula) {
		this.idMatricula = idMatricula;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public List<Asignatura> getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(List<Asignatura> asignaturas) {
		this.asignaturas = asignaturas;
	}

	public AlumnoDTO getAlumno() {
		return alumno;
	}

	public void setAlumno(AlumnoDTO alumno) {
		this.alumno = alumno;
	}
	
}
