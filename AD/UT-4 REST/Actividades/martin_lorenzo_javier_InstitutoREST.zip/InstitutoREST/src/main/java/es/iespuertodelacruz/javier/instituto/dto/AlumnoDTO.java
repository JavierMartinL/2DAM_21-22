package es.iespuertodelacruz.javier.instituto.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import es.iespuertodelacruz.javier.instituto.entity.Alumno;

public class AlumnoDTO {

	private String dni;
	private String nombre;
	private String apellidos;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Date fechaNacimiento;
	
	public AlumnoDTO() { }
	
	public AlumnoDTO(Alumno alumno) {
		this.dni = alumno.getDni();
		this.nombre = alumno.getNombre();
		this.apellidos = alumno.getApellidos();
		if (alumno.getFechanacimiento() != null) {
			this.fechaNacimiento = new Date(alumno.getFechanacimiento().longValue());
		} else {
			this.fechaNacimiento = null;
		}
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
}
