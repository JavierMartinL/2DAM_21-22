package es.iespuertodelacruz.javier.instituto.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.dto.MatriculaDTO;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;
import es.iespuertodelacruz.javier.instituto.service.MatriculaService;

@RestController
@RequestMapping("/api/matriculas")
public class MatriculaREST {

	@Autowired
	private MatriculaService matriculaService;
	
	@GetMapping
	public List<Matricula> getAll(@RequestParam(required=false, name="year") Integer year) {
		ArrayList<Matricula> matriculas = new ArrayList<Matricula>();
		
		if (year == null) {
			matriculaService.findAll().forEach(m -> matriculas.add((Matricula) m));
		} else {
			matriculaService.findByYear(year).forEach(m -> matriculas.add((Matricula) m));
		}
		
		return matriculas;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> findById(@PathVariable Integer id) {
		Optional<Matricula> optMatricula = matriculaService.findById(id);
		if (optMatricula.isPresent()) {
			return ResponseEntity.ok().body(new MatriculaDTO(optMatricula.get()));
		} else {
			return ResponseEntity.notFound().build();
		}
	}
}
