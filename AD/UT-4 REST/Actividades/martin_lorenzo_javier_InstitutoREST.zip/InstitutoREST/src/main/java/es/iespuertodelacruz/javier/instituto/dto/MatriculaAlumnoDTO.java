package es.iespuertodelacruz.javier.instituto.dto;

import java.util.List;

import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;

public class MatriculaAlumnoDTO {
	
	private int idMatricula;
	private int year;
	private List<Asignatura> asignaturas;
	
	public MatriculaAlumnoDTO() { }
	
	public MatriculaAlumnoDTO(Matricula matricula) {
		this.idMatricula = matricula.getIdmatricula();
		this.year = matricula.getYear();
		this.asignaturas = matricula.getAsignaturas();
	}

	public int getIdMatricula() {
		return idMatricula;
	}

	public void setIdMatricula(int idMatricula) {
		this.idMatricula = idMatricula;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public List<Asignatura> getAsignaturas() {
		return asignaturas;
	}

	public void setAsignaturas(List<Asignatura> asignaturas) {
		this.asignaturas = asignaturas;
	}
	
}
