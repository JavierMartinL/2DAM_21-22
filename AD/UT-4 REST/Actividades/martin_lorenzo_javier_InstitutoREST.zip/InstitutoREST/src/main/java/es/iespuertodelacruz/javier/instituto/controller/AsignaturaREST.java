package es.iespuertodelacruz.javier.instituto.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.service.AsignaturaService;

@RestController
@RequestMapping("/api/asignaturas")
public class AsignaturaREST {

	@Autowired
	private AsignaturaService asignaturaService;
	
	@GetMapping
	public List<Asignatura> getAll(
			@RequestParam(required=false, name="nombre") String nombre,
			@RequestParam(required=false, name="curso") String curso
			) {
		ArrayList<Asignatura> asignaturas = new ArrayList<Asignatura>();
		if (nombre != null && !nombre.trim().equals("")) {
			asignaturaService
				.findByNombre(nombre + "%")
				.forEach(a -> asignaturas.add((Asignatura) a));
		} else if (curso != null && !curso.trim().equals("")) { 
			asignaturaService
				.findByCurso("%" + curso + "%")
				.forEach(a -> asignaturas.add((Asignatura) a));
		}else {
			asignaturaService
				.findAll()
				.forEach(a -> asignaturas.add((Asignatura) a));
		}
		return asignaturas;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getById(@PathVariable Integer id) {
		Optional<Asignatura> optAsignatura = asignaturaService.findById(id);
		if (optAsignatura.isPresent())
			return ResponseEntity.ok().body(optAsignatura);
		else
			return ResponseEntity.notFound().build();
	}
	
	@PostMapping
	public ResponseEntity<?> save(@RequestBody Asignatura asignatura){
		try {
			Asignatura save = asignaturaService.save(asignatura);
			return ResponseEntity.status(HttpStatus.CREATED).body(save);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al crear la Asignatura");
		}
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<?> update(
			@PathVariable Integer id,
			@RequestBody Asignatura updateAsignatura
			) {
		Optional<Asignatura> optAsignatura = asignaturaService.findById(id);
		if (optAsignatura.isPresent()) {
			Asignatura asignatura = optAsignatura.get();
			asignatura.setNombre(updateAsignatura.getNombre());
			asignatura.setCurso(updateAsignatura.getCurso());
			return ResponseEntity.ok(asignaturaService.save(asignatura));
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable Integer id){
		Optional<Asignatura> optAsignatura = asignaturaService.findById(id);
		if(optAsignatura.isPresent()) {
			try {
				asignaturaService.deleteById(id);
				return ResponseEntity.ok("Asignatura borrada");
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Esta asignatura esta relacionada con alguna matricula");
			}
		}else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}

}
