package es.iespuertodelacruz.javier.instituto.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.iespuertodelacruz.javier.instituto.entity.Alumno;
import es.iespuertodelacruz.javier.instituto.repository.AlumnoRepository;

@Service
public class AlumnoService implements GenericService<Alumno, String> {
	
	@Autowired
	private AlumnoRepository alumnoRepository;

	@Override
	@Transactional(readOnly=true)
	public Iterable<Alumno> findAll() {
		return alumnoRepository.findAll();
	}

	@Override
	@Transactional(readOnly=true)
	public Page<Alumno> findAll(Pageable pageable) {
		return alumnoRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly=true)
	public Optional<Alumno> findById(String id) {
		return alumnoRepository.findById(id);
	}
	
	@Transactional(readOnly=true)
	public List<Alumno> findByNombre(String nombre) {
		return alumnoRepository.findByNombre(nombre);
	}

	@Override
	@Transactional
	public Alumno save(Alumno objeto) {
		return alumnoRepository.save(objeto);
	}

	@Override
	public void deleteById(String id) {
		alumnoRepository.deleteById(id);
	}

}
