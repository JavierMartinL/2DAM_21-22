 package es.iespuertodelacruz.javier.instituto.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.iespuertodelacruz.javier.instituto.dto.AlumnoDTO;
import es.iespuertodelacruz.javier.instituto.dto.MatriculaAlumnoDTO;
import es.iespuertodelacruz.javier.instituto.entity.Alumno;
import es.iespuertodelacruz.javier.instituto.entity.Asignatura;
import es.iespuertodelacruz.javier.instituto.entity.Matricula;
import es.iespuertodelacruz.javier.instituto.service.AlumnoService;
import es.iespuertodelacruz.javier.instituto.service.AsignaturaService;
import es.iespuertodelacruz.javier.instituto.service.MatriculaService;

@RestController
@RequestMapping("/api/alumnos")
public class AlumnoREST {

	@Autowired
	private AlumnoService alumnoService;
	
	@Autowired
	private MatriculaService matriculaService;
	
	@Autowired
	private AsignaturaService asignaturaService;
	
	@GetMapping
	public List<AlumnoDTO> getAll(@RequestParam(required=false, name="name") String name) {
		ArrayList<AlumnoDTO> alumnos = new ArrayList<AlumnoDTO>();
		if (name == null) {
			alumnoService.findAll().forEach(a -> alumnos.add(new AlumnoDTO(a)));
		} else { 
			alumnoService.findByNombre("%" + name + "%").forEach(a -> alumnos.add(new AlumnoDTO(a)));
		}
		return alumnos;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getById(@PathVariable String id) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) 
			return ResponseEntity.ok().body(new AlumnoDTO(optAlumno.get()));
		else
			return ResponseEntity.notFound().build();
	}
	
	@GetMapping("/{id}/matriculas")
	public ResponseEntity<?> getAllMatriculas(@PathVariable String id) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			return ResponseEntity.ok().body(optAlumno.get().getMatriculas());
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@GetMapping("/{idAlumno}/matriculas/{idMatricula}")
	public ResponseEntity<?> getMatriculaById(
			@PathVariable String idAlumno,
			@PathVariable Integer idMatricula
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(idAlumno);
		if (optAlumno.isPresent()) {
			List<Matricula> matriculas = optAlumno.get().getMatriculas();
			for (Matricula matricula : matriculas) {
				if (matricula.getIdmatricula() == idMatricula) {
					return ResponseEntity.ok().body(new MatriculaAlumnoDTO(matricula));
				}
			}
			return ResponseEntity.notFound().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@PostMapping
	public ResponseEntity<?> save(@RequestBody AlumnoDTO alumnoDTO) {
		try {
			Optional<Alumno> optAlumno = alumnoService.findById(alumnoDTO.getDni());
			if (!optAlumno.isPresent()) {
				Alumno alumno = new Alumno();
				alumno.setDni(alumnoDTO.getDni());
				alumno.setNombre(alumnoDTO.getNombre());
				alumno.setApellidos(alumnoDTO.getApellidos());
				alumno.setFechanacimiento(BigInteger.valueOf(alumnoDTO.getFechaNacimiento().getTime()));
				Alumno save = alumnoService.save(alumno);
				return ResponseEntity.status(HttpStatus.CREATED).body(new AlumnoDTO(save));
			} else {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Existe un Alumno con este DNI");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al crear el Alumno");
		}
	}
	
	@PostMapping("/{id}/matriculas")
	public ResponseEntity<?> saveMatricula(
			@PathVariable String id,
			@RequestBody MatriculaAlumnoDTO matriculaDTO
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			try {
				Matricula matricula = new Matricula();
				matricula.setYear(matriculaDTO.getYear());
				matricula.setAlumno(optAlumno.get());
				List<Asignatura> asignaturas = new ArrayList<Asignatura>();
				
				if (matriculaDTO.getAsignaturas() != null) {
					for (Asignatura asignatura : matriculaDTO.getAsignaturas()) {
						Optional<Asignatura> optAsignatura = asignaturaService.findById(asignatura.getIdasignatura());
						if (optAsignatura.isPresent()) {
							asignaturas.add(optAsignatura.get());
						}
					}
				}
				
				matricula.setAsignaturas(asignaturas);
				Matricula save = matriculaService.save(matricula);
				return ResponseEntity.status(HttpStatus.CREATED).body(new MatriculaAlumnoDTO(save));
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al crear la Matricula");
			}
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<?> update(
			@PathVariable String id,
			@RequestBody AlumnoDTO alumnoDTO
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			Alumno alumno = optAlumno.get();
			alumno.setNombre(alumnoDTO.getNombre());
			alumno.setApellidos(alumnoDTO.getApellidos());
			if (alumnoDTO.getFechaNacimiento() != null)
				alumno.setFechanacimiento(BigInteger.valueOf(alumnoDTO.getFechaNacimiento().getTime()));
			Alumno save = alumnoService.save(alumno);
			return ResponseEntity.ok(new AlumnoDTO(save));
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}
	
	@PutMapping("/{idAlumno}/matriculas/{idMatricula}")
	public ResponseEntity<?> updateMatricula(
			@PathVariable String idAlumno,
			@PathVariable Integer idMatricula,
			@RequestBody MatriculaAlumnoDTO matriculaDTO
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(idAlumno);
		if (optAlumno.isPresent()) {
			List<Matricula> matriculas = optAlumno.get().getMatriculas();
			for (Matricula matricula : matriculas) {
				if (matricula.getIdmatricula() == idMatricula) {
					if (matriculaDTO.getYear() != 0) {
						matricula.setYear(matriculaDTO.getYear());
					}
					List<Asignatura> asignaturas = new ArrayList<Asignatura>();
					
					if (matriculaDTO.getAsignaturas() != null) {
						for (Asignatura asignatura : matriculaDTO.getAsignaturas()) {
							Optional<Asignatura> optAsignatura = asignaturaService.findById(asignatura.getIdasignatura());
							if (optAsignatura.isPresent()) {
								asignaturas.add(optAsignatura.get());
							}
						}
					}
					
					matricula.setAsignaturas(asignaturas);
					Matricula save = matriculaService.save(matricula);
					return ResponseEntity.ok(new MatriculaAlumnoDTO(save));
				}
			}
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id de la matricula no existe");
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del alumno no existe");
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable String id) {
		Optional<Alumno> optAlumno = alumnoService.findById(id);
		if (optAlumno.isPresent()) {
			try {
				alumnoService.deleteById(id);
				return ResponseEntity.ok("Alumno borrado");
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Este alumno esta relacionado con alguna matricula");
			}
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del registro no existe");
		}
	}
	
	@DeleteMapping("/{idAlumno}/matriculas/{idMatricula}")
	public ResponseEntity<?> deleteMatricula(
			@PathVariable String idAlumno,
			@PathVariable Integer idMatricula
			) {
		Optional<Alumno> optAlumno = alumnoService.findById(idAlumno);
		if (optAlumno.isPresent()) {
			List<Matricula> matriculas = optAlumno.get().getMatriculas();
			for (Matricula matricula : matriculas) {
				if (matricula.getIdmatricula() == idMatricula) {
					matriculaService.deleteById(idMatricula);
					return ResponseEntity.ok("Matricula Eliminada");
				}
			}
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id de la matricula no existe");
		} else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("el id del alumno no existe");
		}
	}
	
}
