/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iespuerto.pro.clienterestaemetmaven;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import static com.iespuerto.pro.clienterestaemetmaven.JerseyHttpClientFactory.getJerseyHTTPSClient;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.client.Client;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author carlos
 */
public class ClienteRestAEMETmaven {
    
    public static void main(String[] args) {
        
        Client client = null;
        try {
            client = getJerseyHTTPSClient();
            
            //url para JSON de la api REST de la AEMET para Puerto de la Cruz
            String url = "https://opendata.aemet.es"
                    + "/opendata/api/prediccion/especifica/municipio/diaria/38028";
            
            //Token duración 5 días. Se debe actualizar. La api key ( el token )
            // se toma en el enlace: "obtención api key" 
            // url para hacerlo: https://opendata.aemet.es/centrodedescargas/inicio
            String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJqYy5pZXNwdWVydG9kZWxhY3"
                    + "J1ekBnbXguZXMiLCJqdGkiOiI4N2MxMTYwMi1hNDQzLTQyNmEtYWQ5MC00ZW"
                    + "Y3YjFjNjQ4ZWUiLCJpc3MiOiJBRU1FVCIsImlhdCI6MTU3MzY4NDYzMywidX"
                    + "NlcklkIjoiODdjMTE2MDItYTQ0My00MjZhLWFkOTAtNGVmN2IxYzY0OGVlIiw"
                    + "icm9sZSI6IiJ9.Uy5dGVUpJEQdMMP8XPhvyQJJkaNUiLO7TD7vF_qFgqM";
            
            System.out.println(token);
            
            //al solicitar los datos con el token del puerto de la cruz nos da
            //un json con enlaces a páginas json que duran poco tiempo
            // En el siguiente ejemplo, los datos de predicción están en la url para "datos"
            /*
              {
                "descripcion" : "exito",
                "estado" : 200,
                "datos" : "https://opendata.aemet.es/opendata/sh/2f14aabd",
                "metadatos" : "https://opendata.aemet.es/opendata/sh/dfd88b22"
              }
            */
            Response response = client
                    .target(url)
                    .request(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + token)
                    .get();
            String json = response.readEntity(String.class);
            System.out.println("La AEMET informa de los siguientes enlaces para la consulta realizada:");
            System.out.println(json);
        
            
            
            //Vamos a hacer uso de Gson para tomar la url con los datos:
            JsonObject jsonObject = new JsonParser().parse(json).getAsJsonObject();

            
            String urlDatos = jsonObject.get("datos").getAsString();
            System.out.println("\n\n\nLa url para los datos de predicción por tanto es:");
            System.out.println(urlDatos);
    
            


            //Ahora vamos a tomar el json que contiene la url que hemos obtenido
            response = client
                    .target(urlDatos)
                    .request(MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + token)
                    .get();
            json = response.readEntity(String.class);
            //System.out.println(json);

            
            //el json obtenido es muy extenso, está compuesto de array y objetos json anidados
            //si lo único que queremos es la predicción para hoy haríamos lo siguiente:
            JsonArray arr = new JsonParser().parse(json).getAsJsonArray();
            jsonObject = arr.get(0).getAsJsonObject().getAsJsonObject("prediccion");
            arr = jsonObject.getAsJsonArray("dia");
            
            //ahora mismo en arr están las predicciones de los 5 días
            //tomamos la posición 0 que es la predicción para hoy
            jsonObject = arr.get(0).getAsJsonObject();
            
            
            //tomamos la descripción de nuboso, etc
            JsonArray estadoCielo = jsonObject.getAsJsonArray("estadoCielo");
            
            
            System.out.println("\n\n\nLa predicción completa para el día de hoy:");
            System.out.println(estadoCielo);
            
            //pienso que en el campo value va el nombre de la imagen a mostrar
            //(habría que descargarla de la aemet para que fuera coherente )
            //y se obtiene info para diferentes periodos del día. Así vamos a 
            //mostrar el texto recorriendo el array anterior:
            System.out.println("\n\n\nPredicción por periodos del día:");
            for (JsonElement jsonElement : estadoCielo) {
                String periodo = jsonElement.getAsJsonObject().get("periodo").getAsString();
                String descripcion = jsonElement.getAsJsonObject().get("descripcion").getAsString();
                System.out.println("Periodo: " + periodo + ": " + descripcion);
            }
            
        } catch (KeyManagementException ex) {
            ex.printStackTrace();
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }
        
        
    }
    
}
