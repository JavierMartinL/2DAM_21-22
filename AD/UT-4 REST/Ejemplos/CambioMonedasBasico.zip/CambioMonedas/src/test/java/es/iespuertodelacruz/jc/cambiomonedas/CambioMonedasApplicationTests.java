package es.iespuertodelacruz.jc.cambiomonedas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CambioMonedasApplicationTests {

	@Test
	void contextLoads() {
	}

}
