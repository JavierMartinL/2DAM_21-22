package es.iespuertodelacruz.javier.instituto.contract;

public abstract class MatriculaEntry {
	public static final String TABLE_NAME = "matriculas";
	
	public static final String COLUMN_ID = "idmatricula";
	public static final String COLUMN_DNI = "dni"; 
	public static final String COLUMN_YEAR = "year";
}
