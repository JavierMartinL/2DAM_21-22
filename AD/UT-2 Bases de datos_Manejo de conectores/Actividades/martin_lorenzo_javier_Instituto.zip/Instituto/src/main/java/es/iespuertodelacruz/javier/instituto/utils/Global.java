package es.iespuertodelacruz.javier.instituto.utils;

public abstract class Global {

    /**
     * Aplicación
     */
    public static String APP_GESTORDDBB = "gdb";

    /**
     * Sesion
     */
    public static String SESSION_MENSAJE = "mensaje";
    public static String SESSION_ERROR = "error";
}
