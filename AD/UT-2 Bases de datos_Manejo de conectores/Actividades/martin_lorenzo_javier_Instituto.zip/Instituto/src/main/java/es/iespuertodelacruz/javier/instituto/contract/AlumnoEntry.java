package es.iespuertodelacruz.javier.instituto.contract;

public abstract class AlumnoEntry {
	public static final String TABLE_NAME = "alumnos";

	public static final String COLUMN_DNI = "dni";
	public static final String COLUMN_NOMBRE = "nombre";
	public static final String COLUMN_APELLIDOS = "apellidos";
	public static final String COLUMN_FECHA_NACIMIENTO = "fechanacimiento";
	
}
