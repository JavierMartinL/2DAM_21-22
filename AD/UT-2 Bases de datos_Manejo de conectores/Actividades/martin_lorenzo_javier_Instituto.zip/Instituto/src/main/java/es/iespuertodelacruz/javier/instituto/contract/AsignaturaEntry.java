package es.iespuertodelacruz.javier.instituto.contract;

public abstract class AsignaturaEntry {
	public static final String TABLE_NAME = "asignaturas";
	
	public static final String COLUMN_ID = "idasignatura";
	public static final String COLUMN_NOMBRE = "nombre"; 
	public static final String COLUMN_CURSO = "curso";
}
