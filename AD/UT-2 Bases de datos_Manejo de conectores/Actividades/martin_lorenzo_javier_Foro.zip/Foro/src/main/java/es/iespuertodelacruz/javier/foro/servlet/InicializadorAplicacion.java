package es.iespuertodelacruz.javier.foro.servlet;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import es.iespuertodelacruz.javier.foro.model.Mensaje;
import es.iespuertodelacruz.javier.foro.utils.Global;
import es.iespuertodelacruz.javier.foro.utils.ManejarFichero;

/**
 * Application Lifecycle Listener implementation class InicializadorAplicacion
 *
 */
public class InicializadorAplicacion implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public InicializadorAplicacion() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  {
    	ManejarFichero mf = (ManejarFichero) sce.getServletContext().getAttribute(Global.MANEJAR_FICHERO);
    	
    	try {
			mf.agregarTexto((Vector<Mensaje>) sce.getServletContext().getAttribute(Global.MENSAJES_VECTOR));
		} catch (IOException e) { }
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
    	String pathToWeb = sce.getServletContext().getRealPath(File.separator);
    	String ruta = pathToWeb + File.separator + "WEB-INF" + File.separator + "mensajes.txt";
    	
    	ManejarFichero mf = new ManejarFichero(ruta);
    	sce.getServletContext().setAttribute(Global.MANEJAR_FICHERO, mf);
    	
    	try {
			Vector<Mensaje> mensajes = mf.leerTodo();
			sce.getServletContext().setAttribute(Global.MENSAJES_VECTOR, mensajes);
		} catch (IOException e) { }
    }
	
}
