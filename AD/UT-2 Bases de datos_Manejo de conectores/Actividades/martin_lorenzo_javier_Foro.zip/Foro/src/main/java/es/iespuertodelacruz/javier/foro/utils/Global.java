package es.iespuertodelacruz.javier.foro.utils;

public class Global {

	public static final String NOMBRE_USUARIO_SESSION = "nombreUsuario";
	public static final String MENSAJES_VECTOR = "mensajes";
	public static final String USUARIOS_CONECTADOS = "usuariosConectados";
	public static final String MANEJAR_FICHERO = "manejarFichero";
	public static final String TIEMPO_ULTIMO_MENSAJE = "ultimoMensaje";
	
}
