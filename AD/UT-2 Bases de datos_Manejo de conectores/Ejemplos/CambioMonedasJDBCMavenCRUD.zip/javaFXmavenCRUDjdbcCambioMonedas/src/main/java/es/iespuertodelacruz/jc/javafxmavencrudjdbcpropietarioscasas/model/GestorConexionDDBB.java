/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.jc.javafxmavencrudjdbcpropietarioscasas.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author carlos
 */
public class GestorConexionDDBB {

    /**
     * @return the conexion
     */
    public Connection getConnection() {
        
        Connection con=null;
        try {
            con = DriverManager.getConnection(jdbcUrl, usuario, clave);
        } catch (SQLException ex) {
            System.exit(1);
        }
     
        return con;
    }

   
  
    

    String jdbcUrl;
    String usuario;
    String clave;
   
    
    
    
    public GestorConexionDDBB(String ddbb,String nombreUsuario, String password){
        jdbcUrl = "jdbc:mysql://localhost/"+ddbb+"?serverTimezone=UTC";
        usuario = nombreUsuario;
        clave = password;
        cargarDriverMysql();

        

      



             
        
    }
    
    

    private static  void cargarDriverMysql(){
      try {
        Class.forName("com.mysql.cj.jdbc.Driver");
      } catch(ClassNotFoundException ex) {
        System.err.println("no carga el driver");
        System.exit(1);
      }        
    }


    


    
}
