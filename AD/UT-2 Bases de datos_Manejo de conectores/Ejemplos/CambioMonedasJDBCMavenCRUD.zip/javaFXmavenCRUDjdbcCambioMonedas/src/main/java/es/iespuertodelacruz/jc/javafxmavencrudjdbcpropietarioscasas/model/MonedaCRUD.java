/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.jc.javafxmavencrudjdbcpropietarioscasas.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author carlos
 */

public class MonedaCRUD{

    GestorConexionDDBB gcdb;
    
    
    public MonedaCRUD(GestorConexionDDBB gc){
        gcdb = gc;
    }
    
    public Moneda getMonedaById(int id) throws SQLException{

        Moneda moneda = null;
        
        Connection conexion = gcdb.getConnection();
        
        
        String query = "SELECT * FROM monedas where idmoneda =  ? ;" ;
        PreparedStatement ps = conexion.prepareStatement(query);
        ps.setInt(1, id);
        ResultSet res = ps.executeQuery();
        while(res.next()){
            int idmoneda = res.getInt("idmoneda");
            String nombre = res.getString("nombre");
            String pais = res.getString("pais");
            
            moneda = new Moneda();
            moneda.setIdMoneda(idmoneda);
            moneda.setNombre(nombre);
            moneda.setPais(pais);
            
            
        }
        ps.close();
        conexion.close();
        
        return moneda;
    }
    

}