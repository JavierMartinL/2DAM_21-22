package es.iespuertodelacruz.jc.javafxmavencrudjdbcpropietarioscasas;

import es.iespuertodelacruz.jc.javafxmavencrudjdbcpropietarioscasas.model.GestorConexionDDBB;
import es.iespuertodelacruz.jc.javafxmavencrudjdbcpropietarioscasas.model.Moneda;
import es.iespuertodelacruz.jc.javafxmavencrudjdbcpropietarioscasas.model.MonedaCRUD;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class FXMLController implements Initializable {
    
    @FXML
    private Label label;
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws SQLException {
        System.out.println("You clicked me!");
       
        
        GestorConexionDDBB gc = new GestorConexionDDBB("cambiomonedas","root","1q2w3e4r");
        
        MonedaCRUD monedaCRUD = new MonedaCRUD(gc);
        Moneda moneda = monedaCRUD.getMonedaById(1);
        label.setText("nombre moneda: " + moneda.getNombre());
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
