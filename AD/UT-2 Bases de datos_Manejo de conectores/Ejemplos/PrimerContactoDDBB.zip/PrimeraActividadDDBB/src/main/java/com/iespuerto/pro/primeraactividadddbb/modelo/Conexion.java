/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iespuerto.pro.primeraactividadddbb.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author carlos
 */
public class Conexion {
    

    String jdbcUrl;
    String usuario;
    String clave;
    Connection conexion=null;
    
    public Conexion(String ddbb,String nombreUsuario, String password){
        jdbcUrl = "jdbc:mysql://localhost/"+ddbb+"?serverTimezone=UTC";
        usuario = nombreUsuario;
        clave = password;
        cargarDriverMysql();
        
    }
    
    

    public static  void cargarDriverMysql(){
      try {
        Class.forName("com.mysql.cj.jdbc.Driver");
      } catch(ClassNotFoundException ex) {
        System.err.println("no carga el driver");
        System.exit(1);
      }        
    }
    
    
    public Connection mysql() throws SQLException{
        return mysql(jdbcUrl,usuario,clave);
    }
    
    public Connection mysql(String url, String user, String pass) throws SQLException{

        conexion=null;
   
        if(url != null && !url.isEmpty())
            jdbcUrl = url;

        if(user != null && !user.isEmpty()){
            usuario = user;
        }


        if(pass != null && !pass.isEmpty()){
            clave = pass;
        }
      
        Connection con = DriverManager.getConnection(jdbcUrl, usuario, clave);

        System.out.println("Conectado a mysql!");
        conexion = con;


        return conexion;

    }


    public void getPersonas() throws SQLException{
        if( conexion == null){
            conexion = mysql();
        }    
        
        
/*
        String consulta = "select * from Persona where nombre = ? ";
Connection conexion= DriverManager.getConnection("jdbc:mysql://localhost/prueba", "root", "root");
PreparedStatement sentencia= conexion.prepareStatement(consulta);
sentencia.setString(1, "pepe");
ResultSet rs = sentencia.executeQuery();
        
        */   
        String query = "SELECT * FROM personas where nombre like  ? ;" ;
        PreparedStatement ps = conexion.prepareStatement(query);
        ps.setString(1, "%a%");
        ResultSet res = ps.executeQuery();
        while(res.next()){
            
            System.out.print(res.getInt("idpersona") + "; ");
            System.out.print(res.getString("nombre") + "; ");
            System.out.print(res.getString("edad") + "; ");
            System.out.print(res.getString("altura") + "; ");
            System.out.println("");
        }
        ps.close();
    }
    
    
}
