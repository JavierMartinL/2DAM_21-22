package es.iespuertodelacruz.javier.tarea21enero.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import es.iespuertodelacruz.javier.tarea21enero.entity.Asiento;

public interface AsientoRepository extends JpaRepository<Asiento, Integer> {

}
