package es.iespuertodelacruz.javier.tarea21enero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea21eneroApplicationTests {

	@Test
	void contextLoads() {
	}

}
