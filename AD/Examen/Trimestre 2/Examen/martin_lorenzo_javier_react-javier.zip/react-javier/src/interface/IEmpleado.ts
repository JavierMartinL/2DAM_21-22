export interface IEmpleado {
  id: number;
  apellidos: string;
  calle: string;
  fechaContrato: string;
  municipio: string;
  nombre: string;
  numero: number;
}