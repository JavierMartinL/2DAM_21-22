package es.iespuertodelacruz.javier.javierexamen1.utils;

public abstract class Global {

	public static String APP_GESTORDDBB = "gdb";
	public static String SESSION_MENSAJE = "mensaje";
	
}
