package es.iespuertodelacruz.javier.javierexamen1.contract;

public abstract class EmpleadoEntry {
	public static final String TABLE_NAME = "empleados";

	public static final String COLUMN_ID = "id";
	public static final String COLUMN_NOMBRE = "nombre";
	public static final String COLUMN_APELLIDOS = "apellidos";
	public static final String COLUMN_FECHA_CONTRATO = "fecha_contrato";
	public static final String COLUMN_JEFE = "jefe";
	public static final String COLUMN_NUMERO = "numero";
	public static final String COLUMN_CALLE = "calle";
	public static final String COLUMN_MUNICIPIO= "municipio";
	
}
