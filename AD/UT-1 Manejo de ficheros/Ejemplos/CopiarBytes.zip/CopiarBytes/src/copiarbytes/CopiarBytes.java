package copiarbytes;

import java.io.*;

public class CopiarBytes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            copia(args[0], args[1]);
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    static void copia (String origen, String destino) throws IOException {
      try{
            // Obtener los nombres de los ficheros de origen y destino
            // y abrir la conexi�n a los ficheros.
        FileInputStream fentrada = new FileInputStream(origen);
        FileOutputStream fsalida = new FileOutputStream(destino);
            // Crear una variable para leer el flujo de bytes del origen
        byte[] buffer= new byte[256];
        while (true) {
                 // Leer el flujo de bytes
             int n = fentrada.read(buffer);
                 // Si no queda nada por leer, salir del while
             if (n < 0)
                 break;
                 // Escribir el flujo de bytes le�dos al fichero destino
             fsalida.write(buffer, 0, n);
            }
            // Cerrar los ficheros
        fentrada.close();
        fsalida.close();
      }catch(IOException ex){
            System.out.println(ex.getMessage()); 
      }    
    }
}
