/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabajandoficheros;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Random;


/**
 *
 * @author carlos
 */
public class TrabajandoFicheros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Path path = Paths.get("fichero.txt");
        long i=0;
        long size =0;
        do{
            boolean finalizar = false;
            try(BufferedWriter bw =  Files.newBufferedWriter(path,
                    StandardOpenOption.APPEND,
                    StandardOpenOption.CREATE
                    )){

                PrintWriter pw = new PrintWriter(bw); 

                Random rnd = new Random();
                int longitud = 'z' - 'a';

                do{
                    String texto = ""+i;
                    for (int j = 0; j < 79; j++) {
                        texto += ((char)(rnd.nextInt(longitud) + 'a'));

                    }

                    pw.printf("%s \n", texto);

                    i++;

                    if( i % 1000000 == 0)
                        finalizar=true;
                }while(!finalizar);

               
                
            } catch (IOException ex) {
                System.out.println(ex);
            }    
            
            File file = new File("fichero.txt");
            size = file.length();
        }while(size < 1000000000);
      
    }
    
}
