/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabajandoficheros;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author carlos
 */
public class LeyendoFichero {
    
    public static void main(String[] args)  {
        Path path = Paths.get("fichero.txt");
        
        
        
            List<String> texto = new ArrayList<String>();
            
            /*
            texto= Files.readAllLines(path);
            
            for (String string : texto) {
                System.out.println(string);
            }
            
            */
            
            
            try(BufferedReader br =  Files.newBufferedReader(path)){
                String linea;
                do{
                    linea = br.readLine();
                    System.out.println(linea);
                }while( linea != null );
                
            } catch (IOException ex) {
                Logger.getLogger(LeyendoFichero.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            try{
                Files.lines(path)
                        .forEach(p->System.out.println(p));
            
            } catch (IOException ex) {
                Logger.getLogger(LeyendoFichero.class.getName()).log(Level.SEVERE, null, ex);
            }
            
           
    
        
    }
    
}
