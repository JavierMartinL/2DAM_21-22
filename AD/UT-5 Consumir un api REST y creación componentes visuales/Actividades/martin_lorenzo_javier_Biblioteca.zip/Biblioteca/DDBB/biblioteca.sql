DROP DATABASE IF EXISTS biblioteca;
CREATE DATABASE biblioteca;
USE biblioteca;

/*
autores(autorid,nombre,apellidos,nacionalidad)
aceptado nulo en apellidos y nacionalidad
*/
CREATE TABLE autores (
  autorid INT AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  apellidos VARCHAR(50),
  nacionalidad VARCHAR(50),
  
  CONSTRAINT pk_autores PRIMARY KEY (autorid)
);

/*
libros(libroid,editorial, titulo) NO SE ADMINTEN NULOS EN NINGÚN CAMPO
*/
CREATE TABLE libros (
  libroid INT AUTO_INCREMENT NOT NULL,
  editorial VARCHAR(50) NOT NULL,
  titulo VARCHAR(50) NOT NULL,

  CONSTRAINT pk_libros PRIMARY KEY (libroid)
);

/*
autor_libro(autorlibroid, fkautorid/autores, fklibroid/libros)
restricción (constraint) unique en el par( fkautorid, fklibroid) NO SE ADMITEN NULOS EN NINGÚN CAMPO
*/
CREATE TABLE autor_libro (
  autorlibroid INT AUTO_INCREMENT NOT NULL,
  fkautorid INT NOT NULL,
  fklibroid INT NOT NULL,

  CONSTRAINT pk_autores_libros PRIMARY KEY (autorlibroid),
  CONSTRAINT fk_autores FOREIGN KEY(fkautorid) REFERENCES autores (autorid),
  CONSTRAINT fk_libros FOREIGN KEY (fklibroid) REFERENCES libros (libroid),
  CONSTRAINT uc_autor_libro UNIQUE (fkautorid, fklibroid) 
);

/*
clientes(clienteid, nombre, apellidos, direccion)
aceptado nulo en apellidos y direccion
*/
CREATE TABLE clientes (
  clienteid INT AUTO_INCREMENT NOT NULL,
  nombre VARCHAR(50) NOT NULL,
  apellidos VARCHAR(50),
  direccion VARCHAR(50),

  CONSTRAINT pk_clientes PRIMARY KEY (clienteid)
);

/*
ejemplares(ejemplarid, localizacion, fklibroid/libros) NO SE ADMINTEN NULOS EN NINGÚN CAMPO
*/
CREATE TABLE ejemplares (
  ejemplarid INT AUTO_INCREMENT NOT NULL,
  localizacion VARCHAR(50) NOT NULL,
  fklibroid INT NOT NULL,

  CONSTRAINT pk_ejemplares PRIMARY KEY (ejemplarid),
  CONSTRAINT fk_ejemplar_libro FOREIGN KEY (fklibroid) REFERENCES libros (libroid)
);



/*
prestamos(prestamoid, fkejemplarid/ejemplares, fkclienteid/clientes, fechaprestamo, fechadevolucion)
aceptado nulo en fechadevolucion. restricción (constraint) unique para el conjunto de campos(fkejemplarid, fkclienteid, fechaprestamo)
*/
CREATE TABLE prestamos (
  prestamoid INT AUTO_INCREMENT NOT NULL,
  fkejemplarid INT NOT NULL,
  fkclienteid INT NOT NULL,
  fechaprestamo BIGINT NOT NULL,
  fechadevolucion BIGINT,

  CONSTRAINT pk_prestamos PRIMARY KEY (prestamoid),
  CONSTRAINT fk_prestamo_ejemplar FOREIGN KEY (fkejemplarid) REFERENCES ejemplares (ejemplarid),
  CONSTRAINT fk_prestamo_cliente FOREIGN KEY (fkclienteid) REFERENCES clientes (clienteid),
  CONSTRAINT uc_ejemplar_cliente_fecha UNIQUE (fkejemplarid, fkclienteid, fechaprestamo)
);

/*
operadores(operadorid,nick,password) NO SE ADMITE NULO EN NINGÚN CAMPO
password es de tipo texto varchar(200)  y será un hash. restricción (constraint) unique para campo: nick
*/
CREATE TABLE operadores (
  operadorid INT AUTO_INCREMENT NOT NULL,
  nick VARCHAR(50) NOT NULL,
  password VARCHAR(200) NOT NULL,

  CONSTRAINT pk_operadores PRIMARY KEY (operadorid),
  CONSTRAINT uc_operador UNIQUE (operadorid)
);

INSERT INTO autores (nombre, apellidos, nacionalidad) VALUES ("J.K.", "Rowling", "Reino Unido");
INSERT INTO autores (nombre, apellidos, nacionalidad) VALUES ("Suzanne", "Collins", "Estados Unidos");
INSERT INTO autores (nombre, apellidos, nacionalidad) VALUES ("J.R.R.", "Tolkien", "Reino Unido");
INSERT INTO autores (nombre, apellidos, nacionalidad) VALUES ("Dan", "Brown", "Estados Unidos");

INSERT INTO libros (editorial, titulo) VALUES ("Bloomsbury Publishing", "Harry Potter");
INSERT INTO libros (editorial, titulo) VALUES ("Bloomsbury Publishing", "Harry Potter y la piedra filosofal");
INSERT INTO libros (editorial, titulo) VALUES ("Scholastic Corporation", "Los juegos del hambre");
INSERT INTO libros (editorial, titulo) VALUES ("Ediciones Minotauro", "El señor de los anillos");
INSERT INTO libros (editorial, titulo) VALUES ("Umbriel Editores", "El Código Da Vinci");

INSERT INTO autor_libro (fkautorid, fklibroid) VALUES (1, 1);
INSERT INTO autor_libro (fkautorid, fklibroid) VALUES (1, 2);
INSERT INTO autor_libro (fkautorid, fklibroid) VALUES (2, 3);
INSERT INTO autor_libro (fkautorid, fklibroid) VALUES (3, 4);
INSERT INTO autor_libro (fkautorid, fklibroid) VALUES (4, 5);

INSERT INTO ejemplares (localizacion, fklibroid) VALUES ("Biblioteca", 1);
INSERT INTO ejemplares (localizacion, fklibroid) VALUES ("Biblioteca", 2);
INSERT INTO ejemplares (localizacion, fklibroid) VALUES ("Biblioteca", 3);
INSERT INTO ejemplares (localizacion, fklibroid) VALUES ("Biblioteca", 4);
INSERT INTO ejemplares (localizacion, fklibroid) VALUES ("Biblioteca", 5);

INSERT INTO clientes (nombre, apellidos, direccion) VALUES ("Juan", "Pérez", "Calle falsa 123");
INSERT INTO clientes (nombre, apellidos, direccion) VALUES ("Pedro", "García", "Calle falsa 123");
INSERT INTO clientes (nombre, apellidos, direccion) VALUES ("María", "García", "Calle falsa 123");

INSERT INTO prestamos (fkejemplarid, fkclienteid, fechaprestamo) VALUES (1, 1, 1500000000);
INSERT INTO prestamos (fkejemplarid, fkclienteid, fechaprestamo) VALUES (2, 1, 1500000000);
INSERT INTO prestamos (fkejemplarid, fkclienteid, fechaprestamo) VALUES (3, 2, 1500000000);

INSERT INTO operadores (nick, password) VALUES ("admin", "$2a$10$OTf0sGp0e9dxFSOEpZxp..FkLI/45Mr4H5nTBSZicutWBXJMLkn1i");
INSERT INTO operadores (nick, password) VALUES ("user", "$2a$10$OTf0sGp0e9dxFSOEpZxp..FkLI/45Mr4H5nTBSZicutWBXJMLkn1i");
INSERT INTO operadores (nick, password) VALUES ("javier", "$2a$10$OTf0sGp0e9dxFSOEpZxp..FkLI/45Mr4H5nTBSZicutWBXJMLkn1i");