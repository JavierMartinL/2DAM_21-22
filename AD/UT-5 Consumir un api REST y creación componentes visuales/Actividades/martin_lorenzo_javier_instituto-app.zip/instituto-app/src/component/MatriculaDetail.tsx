import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { IMatricula } from '../interface/IMatricula';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash, faArrowLeftLong } from '@fortawesome/free-solid-svg-icons';
import { IAsignatura } from '../interface/IAsignatura';

interface IState {
  matricula: IMatricula;
}

export default function MatriculaDetail() {
  
  const [ matricula, setMatricula ] = useState<IState>({matricula: {} as IMatricula});

  const { dni, id } = useParams();

  const navigate = useNavigate();

  useEffect(
    () => {
      const getMatricula = async () => {
        let rutaMatricula: string = process.env.REACT_APP_API_URL + "/alumnos/" + dni + "/matriculas/" + id;
        let respuesta = await axios.get(rutaMatricula);
        console.log(respuesta.data);
        setMatricula({ matricula: respuesta.data });
      }
      getMatricula();
    },
    []
  );

  const eliminarMatriculaApi = async () => {
    let ruta: string = process.env.REACT_APP_API_URL + "/alumnos/" + dni + "/matriculas/" + id;
    try {
      const { data } = await axios.delete(ruta)
      console.log(data);
      navegarAtras();
    } catch (error) {
      console.log(error);
    }
  }

  const updateMatricula = () => {
    navigate('/alumnos/' + dni + '/matriculas/' + id + '/update');
  }

  const navegarAtras = () => {
    navigate("/alumnos/" + dni);
  }

  return (
    <div className="row">
      <div className="col-6 offset-3 shadow p-3 mb-5 bg-body rounded mt-5">
        <div className="row m-3">
          <div className="col-1">
            <button type="button" className="btn btn-outline-success" onClick={navegarAtras}><FontAwesomeIcon icon={faArrowLeftLong} /></button>
          </div>
          <div className="offset-5 col-3 text-end">
            <button type="button" className="btn btn-outline-success" onClick={updateMatricula}><FontAwesomeIcon icon={faEdit} /> Editar Matrícula</button>
          </div>
          <div className="col-3 text-start">
            <button type="button" className="btn btn-outline-danger" onClick={eliminarMatriculaApi}><FontAwesomeIcon icon={faTrash} /> Eliminar Matrícula</button>
          </div>
        </div>
        <div className="row">
          <div className="col-6">
            <p className='fs-5 mb-0 fw-light fst-italic'>Id:</p>
            <p className='fs-4 ms-2'>{matricula.matricula.idMatricula}</p>
          </div>
          <div className="col-6">
            <p className='fs-5 mb-0 fw-light fst-italic'>Año: </p>
            <p className='fs-4 ms-2'>{matricula.matricula.year}</p>
          </div>
        </div>
        <hr />
        <div className="row">
          <div className="col-6">
            <p className='fs-3'>Asignaturas: </p>
          </div>
          <div className="col-12">
            <div className="row row-cols-2 row-cols-md-5 m-2">
              {
                matricula.matricula.asignaturas?.map((asignatura: IAsignatura, index: number) => {
                  return (
                    <div className="col">
                      <div className="card btn btn-outline-success text-dark p-3 rounded">
                        <div key={"asig" + index}>
                          <p className='fs-5 m-1'>{asignatura.nombre}</p>
                          <p className="fs-7 m-0">{asignatura.curso}</p>
                        </div>
                      </div>
                    </div>
                  )
                })
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
