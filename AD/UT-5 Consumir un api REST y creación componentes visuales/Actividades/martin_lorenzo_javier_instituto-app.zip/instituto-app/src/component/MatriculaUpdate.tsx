import axios from 'axios';
import React, { FormEvent, useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import Select from 'react-select';
import { IAsignatura } from '../interface/IAsignatura';
import { IMatricula } from '../interface/IMatricula';

export default function MatriculaUpdate() {

  const [ matricula, setMatricula ] = useState<IMatricula>({} as IMatricula);
  const [ asignaturas, setAsignaturas ] = useState<IAsignatura[]>([]);
  const [ selectedAsignaturas, setSelectedAsignaturas ] = useState<any[]>([]);

  const { dni, id } = useParams();
  const navigate = useNavigate();

  const modificarMatriculaApi = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    let inputYear: HTMLFormElement = event.currentTarget.year;

    let year: number = parseInt(inputYear.value);

    const updateMatricula = {
      "year": year,
      "asignaturas": selectedAsignaturas.map((asig: any) => {
        return {
          idasignatura: asig.value,
          curso: "",
          nombre: ""
        }
      })
    }

    const axiosPost = async (rutaMatricula: string) => {
      try {
        const { data } = await axios.put(rutaMatricula, updateMatricula)
        console.log(data);
        navigate('/alumnos/' + dni + "/matriculas/" + id);
      } catch (error) {
        console.log(error);
      }
    }

    axiosPost(process.env.REACT_APP_API_URL + "/alumnos/" + dni + "/matriculas/" + id);
  }

  useEffect(
    () => {
      
      const getMatricula = async () => {
        let rutaMatricula = process.env.REACT_APP_API_URL +  "/alumnos/" + dni + "/matriculas/" + id;
        let respuesta = await axios.get(rutaMatricula);
        console.log(respuesta);
        setMatricula(respuesta.data);
        setSelectedAsignaturas(respuesta.data.asignaturas.map((asig: any) => {
          return {
            value: asig.idasignatura,
            label: asig.nombre + " - " + asig.curso
          }
        }));
      }
      getMatricula();

      const getAsignaturas = async () => {
        let rutaAsignaturas = process.env.REACT_APP_API_URL +  "/asignaturas";
        let respuesta = await axios.get(rutaAsignaturas);
        console.log(respuesta);
        let listaAsignaturas: IAsignatura[] = respuesta.data;
        listaAsignaturas.sort(function (a, b) {
          if (a.curso > b.curso) {
            return 1;
          }
          if (a.curso < b.curso) {
            return -1;
          }
          return 0;
        })
        setAsignaturas(respuesta.data);
      }
      getAsignaturas();
    }, []
  );

  return (
    <div className='row'>
      <div className="col-12 text-center mt-5">
        <h3>Crear una nueva Matrícula</h3>
      </div>
      <div className="col-6 offset-3 shadow p-3 mb-2 bg-body rounded mt-5">
        <form onSubmit={modificarMatriculaApi}>
          <div className="mb-3">
            <label className="form-label">Año:</label>
            <input type="text" className="form-control" id="year" value={matricula.year} />
          </div>
          <Select 
            isMulti
            value={selectedAsignaturas}
            options={asignaturas.map((asignatura: IAsignatura) => {
              return {
                value: asignatura.idasignatura,
                label: asignatura.nombre + " - " + asignatura.curso
                }
              })
            }
            onChange={(selectedAsignaturas: any) => {
              setSelectedAsignaturas(selectedAsignaturas);
              console.log(selectedAsignaturas);
            }}
          />
          <button type="submit" className="btn btn-success mt-2 mb-2 w-100">Guardar</button>
        </form>
      </div>
    </div>
  );
}
