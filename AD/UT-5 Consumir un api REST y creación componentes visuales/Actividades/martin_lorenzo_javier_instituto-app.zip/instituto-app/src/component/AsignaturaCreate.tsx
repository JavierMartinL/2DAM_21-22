import React, { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function AsignaturaCreate() {

  const navigate = useNavigate();

  const agregarAsignaturaApi = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    let inputNombre: HTMLFormElement = event.currentTarget.nombre;
    let inputCurso: HTMLFormElement = event.currentTarget.curso;

    let nombre: string = inputNombre.value;
    let curso: string = inputCurso.value;

    const newAsignatura = {
      "nombre": nombre,
      "curso": curso
    }
    
    const axiosPost = async (rutaAsignatura: string) => {
      try {
        const { data } = await axios.post(rutaAsignatura, newAsignatura)
        console.log(data);
        navigate('/asignaturas');
      } catch (error) {
        console.log(error);
      }
    }

    axiosPost(process.env.REACT_APP_API_URL + "/asignaturas");
  }

  return (
    <div className='row'>
      <div className="col-12 text-center mt-5">
        <h3>Crear una nueva Asignatura</h3>
      </div>
      <div className="col-6 offset-3 shadow p-3 mb-2 bg-body rounded mt-5">
        <form onSubmit={agregarAsignaturaApi}>
          <div className="mb-3">
            <label className="form-label">Nombre:</label>
            <input type="text" className="form-control" id="nombre" />
          </div>
          <div className="mb-3">
            <label className="form-label">Curso:</label>
            <input type="text" className="form-control" id="curso" />
          </div>
          <button type="submit" className="btn btn-success mt-2 mb-2 w-100">Crear</button>
        </form>
      </div>
    </div>
  );
};
