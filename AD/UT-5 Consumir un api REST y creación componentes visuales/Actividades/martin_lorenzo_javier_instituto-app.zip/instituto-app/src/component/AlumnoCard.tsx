import React from 'react';
import { IAlumno } from '../interface/IAlumno';
import { useNavigate } from 'react-router-dom';

interface IProps {
  alumno: IAlumno
}

export default function AlumnoCard (props: IProps) {

  const navigate = useNavigate();
  
  function mostrarDetalleAlumno() {
    navigate("/alumnos/" + props.alumno.dni);
  }

  return (
    <div className="col">
      <div className="card p-3 btn btn-outline-success text-dark shadow mb-5 rounded" onClick={mostrarDetalleAlumno}>
        <div className="card-body">
          <h5 className="card-title">{props.alumno.nombre} {props.alumno.apellidos}</h5>
          <p className="card-text">{props.alumno.dni}</p>
        </div>
      </div>
    </div>
  );
};
