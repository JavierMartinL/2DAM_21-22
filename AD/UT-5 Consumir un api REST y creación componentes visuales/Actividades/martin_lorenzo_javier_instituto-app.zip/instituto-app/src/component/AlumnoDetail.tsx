import React, { useEffect, useState } from 'react';
import { IAlumno } from '../interface/IAlumno';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash, faAdd, faArrowLeftLong } from '@fortawesome/free-solid-svg-icons';
import { IMatricula } from '../interface/IMatricula';

interface IState {
  alumno: IAlumno;
}

export default function AlumnoDetail() {

  const [ alumno, setAlumno ] = useState<IState>({alumno: {} as IAlumno});

  const { dni } = useParams();
  const navigate = useNavigate();

  useEffect(
    () => {
      const getAlumno = async () => {
        let rutaAlumno: string = process.env.REACT_APP_API_URL + "/alumnos/" + dni;
        let respuesta = await axios.get(rutaAlumno);
        let matriculas = await axios.get(rutaAlumno + "/matriculas");

        let alum: IAlumno = respuesta.data;
        alum.matriculas = matriculas.data;

        console.log(alum);
        setAlumno({ alumno: alum });
      }
      getAlumno();
    },
    []
  );

  const eliminarAlumnoApi = async () => {
    let ruta: string = process.env.REACT_APP_API_URL + "/alumnos/" + dni;
    try {
      const { data } = await axios.delete(ruta)
      console.log(data); 
      navigate('/alumnos');
    } catch (error) {
      console.log(error);
    }
  }

  const nuevaMatricula = () => {
    navigate("/alumnos/" + dni + "/matriculas/create")
  }

  const mostrarDetalleMatricula = (matricula: IMatricula) => {
    navigate('/alumnos/' + dni + '/matriculas/' + matricula.idmatricula);
  }

  const editarAlumno = () => {
    navigate("/alumnos/" + dni + "/update")
  }

  const navegarAtras = () => {
    navigate('/alumnos');
  }

  return (
    <div className="row">
      <div className="col-6 offset-3 shadow p-3 mb-5 bg-body rounded mt-5">
        <div className="row m-3">
        <div className="col-1">
            <button type="button" className="btn btn-outline-success" onClick={navegarAtras}><FontAwesomeIcon icon={faArrowLeftLong} /></button>
          </div>
          <div className="offset-5 col-3 text-end">
            <button type="button" className="btn btn-outline-success" onClick={editarAlumno}><FontAwesomeIcon icon={faEdit} /> Editar Alumno</button>
          </div>
          <div className="col-3 text-start">
            <button type="button" className="btn btn-outline-danger" onClick={eliminarAlumnoApi}><FontAwesomeIcon icon={faTrash} /> Eliminar Alumno</button>
          </div>
        </div>
        <div className="row">
          <div className="col-6">
            <p className='fs-5 mb-0 fw-light fst-italic'>Nombre:</p> 
            <p className='fs-4 ms-2'>{alumno.alumno.nombre}</p>
          </div>
          <div className="col-6">
            <p className='fs-5 mb-0 fw-light fst-italic'>Apellidos: </p>
            <p className='fs-4 ms-2'>{alumno.alumno.apellidos}</p>
          </div>
          <div className="col-6">
            <p className='fs-5 mb-0 fw-light fst-italic'>Dni:</p>
            <p className='fs-4 ms-2'>{alumno.alumno.dni}</p>
          </div>
          <div className="col-6">
            <p className='fs-5 mb-0 fw-light fst-italic'>Fecha Nacimiento: </p>
            <p className='fs-4 ms-2'>{alumno.alumno.fechaNacimiento}</p>
          </div>
        </div>
        <hr />
        <div className="row">
          <div className="col-6">
            <p className='fs-3'>Matrículas: </p>
          </div>
          <div className="col-5 text-end ">
            <button type="button" className="btn btn-outline-success" onClick={nuevaMatricula}><FontAwesomeIcon icon={faAdd} /> Nueva Matrícula</button>
          </div>
          <div className="col-12">
            <div className="row row-cols-2 row-cols-md-5 m-2">
              {
                alumno.alumno.matriculas?.map((matricula: IMatricula, index: number) => {
                  return (
                    <div className="col">
                      <div className="card btn btn-outline-success text-dark p-3 rounded" onClick={() => {mostrarDetalleMatricula(matricula)}}>
                        <div key={"mat" + index}>
                          <p className='fs-5 m-0'>{matricula.year}</p>
                        </div>
                      </div>
                    </div>
                  )
                })
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
