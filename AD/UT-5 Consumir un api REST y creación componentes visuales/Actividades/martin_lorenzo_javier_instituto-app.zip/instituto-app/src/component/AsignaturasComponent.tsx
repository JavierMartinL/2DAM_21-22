import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { IAsignatura } from '../interface/IAsignatura';
import AsignaturaCard from './AsignaturaCard';
import { faAdd } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';

interface IState {
  asignaturas: Array<IAsignatura> | null;
}

export default function AsignaturasComponent() {

  const [ asignaturas, setAsignaturas ] = useState<IState>({asignaturas: new Array<IAsignatura>()});

  const navigate = useNavigate();

  const getAsignaturas = async () => {
    let rutaAsignaturas = process.env.REACT_APP_API_URL +  "/asignaturas";
    let respuesta = await axios.get(rutaAsignaturas);
    console.log(respuesta);
    let listaAsignaturas: IAsignatura[] = respuesta.data;
    listaAsignaturas.sort(function (a, b) {
      if (a.curso > b.curso) {
        return 1;
      }
      if (a.curso < b.curso) {
        return -1;
      }
      return 0;
    })
    setAsignaturas({ asignaturas: respuesta.data });
  }

  useEffect(
    () => {
      getAsignaturas();
    },
    []
  );

  function navegar () {
    navigate("/asignaturas/crear");
  }

  return (
    <>
      <div className="row m-3">
        <div className="offset-10 col-2 text-center">
          <button type="button" className="btn btn-outline-success" onClick={navegar}><FontAwesomeIcon icon={faAdd} /> Nueva Asignatura</button>
        </div>
      </div>
      <div className="row row-cols-2 row-cols-md-5 m-2">
          {
            asignaturas.asignaturas?.map((asignatura: IAsignatura, index: number) => {
              return (
                <AsignaturaCard key={"asig" + index} asignatura={asignatura} reloadAsignaturas={getAsignaturas} />
              )
            })
          }
      </div>
    </>
  )
}