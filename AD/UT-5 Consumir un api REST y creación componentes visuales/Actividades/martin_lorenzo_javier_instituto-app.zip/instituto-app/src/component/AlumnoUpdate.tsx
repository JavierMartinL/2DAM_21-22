import React, { FormEvent, useEffect, useState } from 'react'
import axios from 'axios';
import { IAlumno } from '../interface/IAlumno';
import { useParams, useNavigate } from 'react-router-dom';

interface IState {
  alumno: IAlumno;
}

export default function AlumnoUpdate() {

  const [ alumno, setAlumno] = useState<IState>({alumno: {} as IAlumno});

  const { dni } = useParams();
  const navigate = useNavigate();

  useEffect(
    () => {
      const getAlumno = async () => {
        let rutaAlumno: string = process.env.REACT_APP_API_URL + "/alumnos/" + dni;
        let respuesta = await axios.get(rutaAlumno);
        console.log(respuesta);
        setAlumno({ alumno: respuesta.data });
      }
      getAlumno();
    },
    []
  );

  const modificarAlumnoApi = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    let inputNombre: HTMLFormElement = event.currentTarget.nombre;
    let inputApellidos: HTMLFormElement = event.currentTarget.apellidos;
    let inputFechaNacimiento: HTMLFormElement = event.currentTarget.fechaNacimiento;

    let nombre: string = inputNombre.value;
    let apellidos: string = inputApellidos.value;
    let fechaNacimiento: Date = inputFechaNacimiento.valueAsDate;

    const updateAlumno = {
      "dni": dni,
      "nombre": nombre,
      "apellidos": apellidos,
      "fechaNacimiento": fechaNacimiento
    }
    
    const axiosPut = async (rutaAlumno: string) => {
      console.log("alumno")
      console.log(updateAlumno)
      try {
        const { data } = await axios.put(rutaAlumno, updateAlumno)
        console.log(data);
        navigate('/alumnos/' + dni);
      } catch (error) {
        console.log(error);
      }
    }

    axiosPut(process.env.REACT_APP_API_URL + "/alumnos/" + dni);
  }

  return (
    <div className='row'>
      <div className="col-12 text-center mt-5">
        <h3>Modificar datos de un Alumno</h3>
      </div>
      <div className="col-6 offset-3 shadow p-3 mb-2 bg-body rounded mt-5">
        <form onSubmit={modificarAlumnoApi}>
          <div className="mb-3">
            <label className="form-label">DNI:</label>
            <input type="text" className="form-control" id="dni" readOnly defaultValue={alumno.alumno.dni} />
          </div>
          <div className="mb-3">
            <label className="form-label">Nombre:</label>
            <input type="text" className="form-control" id="nombre" defaultValue={alumno.alumno.nombre} />
          </div>
          <div className="mb-3">
            <label className="form-label">Apellidos:</label>
            <input type="text" className="form-control" id="apellidos" defaultValue={alumno.alumno.apellidos} />
          </div>
          <div className="mb-3">
            <label className="form-label">Fecha Nacimiento:</label>
            <input type="date" className="form-control" id="fechaNacimiento" placeholder='dd/MM/yyyy' defaultValue={alumno.alumno.fechaNacimiento} />
          </div>
          <button type="submit" className="btn btn-success mt-2 mb-2 w-100">Guardar</button>
        </form>
      </div>
    </div>
  );
}
