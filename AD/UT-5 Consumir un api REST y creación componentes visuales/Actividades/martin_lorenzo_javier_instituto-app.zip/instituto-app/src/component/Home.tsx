import { faBook, faUserGraduate } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { MouseEvent } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {

  const navigate = useNavigate();

  function navegar(event: MouseEvent<HTMLButtonElement>) {
    event.preventDefault();

    switch(event.currentTarget.name) {
      case "alumnos":
        navigate("/alumnos")
        break;
      case "asignaturas":
        navigate("/asignaturas")
        break;
    }


  }

  return (
    <div className='row text-center mt-5'>
      <div className="offset-4 col-2 mt-5">
        <button className='text-dark btn btn-outline-success fs-1 p-5' onClick={navegar} name="alumnos">
          <FontAwesomeIcon icon={faUserGraduate} fontSize={100} />
          <p className='mb-0 mt-3'>Alumnos</p>
        </button>
      </div>
      <div className="col-2 mt-5">
        <button className='text-dark btn btn-outline-success fs-1 p-5' onClick={navegar} name="asignaturas">
        <FontAwesomeIcon icon={faBook} fontSize={100} />
          <p className='mb-0 mt-3'>Asignaturas</p>
        </button>
      </div>
    </div>
  );
}