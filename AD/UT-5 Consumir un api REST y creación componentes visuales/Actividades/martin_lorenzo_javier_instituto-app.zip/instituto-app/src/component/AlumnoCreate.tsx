import React, { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function AlumnoCreate() {

  const navigate = useNavigate();

  const agregarAlumnoApi = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    let inputDni: HTMLFormElement = event.currentTarget.dni;
    let inputNombre: HTMLFormElement = event.currentTarget.nombre;
    let inputApellidos: HTMLFormElement = event.currentTarget.apellidos;
    let inputFechaNacimiento: HTMLFormElement = event.currentTarget.fechaNacimiento;

    let dni: string = inputDni.value;
    let nombre: string = inputNombre.value;
    let apellidos: string = inputApellidos.value;
    let fechaNacimiento: Date = inputFechaNacimiento.valueAsDate;

    const newAlumno = {
      "dni": dni,
      "nombre": nombre,
      "apellidos": apellidos,
      "fechaNacimiento": fechaNacimiento
    }
    
    const axiosPost = async (rutaAlumno: string) => {
      try {
        const { data } = await axios.post(rutaAlumno, newAlumno)
        console.log(data);
        navigate('/alumnos');
      } catch (error) {
        console.log(error);
      }
    }

    axiosPost(process.env.REACT_APP_API_URL + "/alumnos");
  }

  return (
    <div className='row'>
      <div className="col-12 text-center mt-5">
        <h3>Crear un nuevo Alumno</h3>
      </div>
      <div className="col-6 offset-3 shadow p-3 mb-2 bg-body rounded mt-5">
        <form onSubmit={agregarAlumnoApi}>
          <div className="mb-3">
            <label className="form-label">DNI:</label>
            <input type="text" className="form-control" id="dni" />
          </div>
          <div className="mb-3">
            <label className="form-label">Nombre:</label>
            <input type="text" className="form-control" id="nombre" />
          </div>
          <div className="mb-3">
            <label className="form-label">Apellidos:</label>
            <input type="text" className="form-control" id="apellidos" />
          </div>
          <div className="mb-3">
            <label className="form-label">Fecha Nacimiento:</label>
            <input type="date" className="form-control" id="fechaNacimiento" placeholder='dd/MM/yyyy' />
          </div>
          <button type="submit" className="btn btn-success mt-2 mb-2 w-100">Crear</button>
        </form>
      </div>
    </div>
  );
};
