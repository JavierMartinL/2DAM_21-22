import React from 'react';
import { IAsignatura } from '../interface/IAsignatura';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

interface Iprops {
  reloadAsignaturas: Function,
  asignatura: IAsignatura
}

export default function AsignaturaCard(props: Iprops) {

  const navigate = useNavigate();

  const eliminarAsignaturaApi = async () => {
    let ruta: string = process.env.REACT_APP_API_URL + "/asignaturas/" + props.asignatura.idasignatura;
    try {
      const { data } = await axios.delete(ruta)
      console.log(data); 
      props.reloadAsignaturas();
    } catch (error) {
      console.log(error);
    }
  }

  const editarAsignatura = () => {
    navigate("/asignaturas/" + props.asignatura.idasignatura + "/update");
  }

  return (
    <div className="col">
      <div className="card p-3 shadow mb-5 bg-body rounded">
        <div className="card-body text-center">
          <h5 className="card-title">{props.asignatura.nombre}</h5>
          <p className="card-text">{props.asignatura.curso}</p>
        </div>
        <div className="card-body d-flex justify-content-around">
          <button type="button" className="btn btn-outline-success" onClick={editarAsignatura}><FontAwesomeIcon icon={faEdit} /></button>
          <button type="button" className="btn btn-outline-danger" onClick={eliminarAsignaturaApi}><FontAwesomeIcon icon={faTrash} /></button>
        </div>
      </div>
    </div>
  )
}