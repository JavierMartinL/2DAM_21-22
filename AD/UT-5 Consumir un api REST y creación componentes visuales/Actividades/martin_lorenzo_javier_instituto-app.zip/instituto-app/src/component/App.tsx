import React from 'react';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome } from '@fortawesome/free-solid-svg-icons';

import Home from './Home';
import AlumnosComponent from './AlumnosComponent';
import AsignaturasComponent from './AsignaturasComponent';
import AlumnoDetail from './AlumnoDetail';
import AlumnoCreate from './AlumnoCreate';
import AsignaturaCreate from './AsignaturaCreate';
import MatriculaDetail from './MatriculaDetail';
import AlumnoUpdate from './AlumnoUpdate';
import AsignaturaUpdate from './AsignaturaUpdate';
import MatriculaCreate from './MatriculaCreate';
import MatriculaUpdate from './MatriculaUpdate';

export default function App() {
  return (
    <div className="container-fluid">
      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/alumnos" element={<AlumnosComponent />} />
          <Route path="/alumnos/:dni" element={<AlumnoDetail />} />
          <Route path="/alumnos/crear" element={<AlumnoCreate />} />
          <Route path="/alumnos/:dni/update" element={<AlumnoUpdate />} />
          <Route path='/alumnos/:dni/matriculas/create' element={<MatriculaCreate />} />
          <Route path='/alumnos/:dni/matriculas/:id' element={<MatriculaDetail />} />
          <Route path='/alumnos/:dni/matriculas/:id/update' element={<MatriculaUpdate />} />
          <Route path="/asignaturas" element={<AsignaturasComponent />} />
          <Route path="/asignaturas/crear" element={<AsignaturaCreate />} />
          <Route path="/asignaturas/:id/update" element={<AsignaturaUpdate />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/"><FontAwesomeIcon icon={faHome} /></Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/alumnos">Alumnos</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link disabled" to="/matriculas">Matriculas</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/asignaturas">Asignaturas</Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  )
}