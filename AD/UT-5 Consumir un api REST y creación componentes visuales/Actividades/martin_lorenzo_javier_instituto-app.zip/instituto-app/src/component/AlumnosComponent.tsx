import axios from 'axios';
import React, { useState, useEffect } from 'react';
import AlumnoCard from './AlumnoCard';
import { IAlumno } from '../interface/IAlumno';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAdd } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';

interface IState {
  alumnos: Array<IAlumno>;
}

export default function AlumnosComponent() {

  const [ alumnos, setAlumnos ] = useState<IState>({alumnos: new Array<IAlumno>()});

  const navigate = useNavigate();

  useEffect(
    () => {
      const getAlumnos = async () => {
        let rutaAlumnos = process.env.REACT_APP_API_URL + "/alumnos";
        let respuesta = await axios.get(rutaAlumnos);
        console.log(respuesta);
        setAlumnos({ alumnos: respuesta.data });
      }
      getAlumnos();
    },
    []
  );

  function navegar () {
    navigate("/alumnos/crear");
  }

  return (
    <>
      <div className="row m-3">
        <div className="offset-10 col-2 text-center">
          <button type="button" className="btn btn-outline-success" onClick={navegar}><FontAwesomeIcon icon={faAdd} /> Nuevo Alumno</button>
        </div>
      </div>
      <div className="row row-cols-2 row-cols-md-5 m-2">
        {
          alumnos.alumnos?.map((alumno: IAlumno, index: number) => {
            return (
              <AlumnoCard key={"alu" + index} alumno={alumno} />
            )
          })
        }
      </div>
    </>
  )
}