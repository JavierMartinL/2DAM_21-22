import React, { useState, useEffect, FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { IAsignatura } from '../interface/IAsignatura';

interface IState {
  asignatura: IAsignatura
}

export default function AsignaturaCreate() {

  const [ asignatura, setAsignatura ] = useState<IState>({asignatura: {} as IAsignatura});

  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(
    () => {
      const getAsignatura = async () => {
        let rutaAsignatura: string = process.env.REACT_APP_API_URL + "/asignaturas/" + id;
        let respuesta = await axios.get(rutaAsignatura);
        console.log(respuesta);
        setAsignatura({ asignatura: respuesta.data });
      }
      getAsignatura();
    },
    []
  );

  const modificarAsignaturaApi = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    let inputNombre: HTMLFormElement = event.currentTarget.nombre;
    let inputCurso: HTMLFormElement = event.currentTarget.curso;

    let nombre: string = inputNombre.value;
    let curso: string = inputCurso.value;

    const updateAsignatura = {
      "nombre": nombre,
      "curso": curso
    }
    
    const axiosPost = async (rutaAsignatura: string) => {
      try {
        const { data } = await axios.put(rutaAsignatura, updateAsignatura)
        console.log(data);
        navigate('/asignaturas');
      } catch (error) {
        console.log(error);
      }
    }

    axiosPost(process.env.REACT_APP_API_URL + "/asignaturas/" + id);
  }

  return (
    <div className='row'>
      <div className="col-12 text-center mt-5">
        <h3>Modificar datos de una Asignatura</h3>
      </div>
      <div className="col-6 offset-3 shadow p-3 mb-2 bg-body rounded mt-5">
        <form onSubmit={modificarAsignaturaApi}>
          <div className="mb-3">
            <label className="form-label">Nombre:</label>
            <input type="text" className="form-control" id="nombre" defaultValue={asignatura.asignatura.nombre} />
          </div>
          <div className="mb-3">
            <label className="form-label">Curso:</label>
            <input type="text" className="form-control" id="curso" defaultValue={asignatura.asignatura.curso} />
          </div>
          <button type="submit" className="btn btn-success mt-2 mb-2 w-100">Guardar</button>
        </form>
      </div>
    </div>
  );
};
