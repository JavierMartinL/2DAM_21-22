import { IAsignatura } from './IAsignatura';

export interface IMatricula {
  idmatricula: number;
  idMatricula: number;
  year: number;
  asignaturas: IAsignatura[];
}