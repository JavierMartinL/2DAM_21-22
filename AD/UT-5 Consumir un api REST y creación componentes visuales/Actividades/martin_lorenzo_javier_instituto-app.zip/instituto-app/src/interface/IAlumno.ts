import { IMatricula } from "./IMatricula";

export interface IAlumno {
  dni: string;
  nombre: string;
  apellidos: string;
  fechaNacimiento: string;
  matriculas: IMatricula[];
}