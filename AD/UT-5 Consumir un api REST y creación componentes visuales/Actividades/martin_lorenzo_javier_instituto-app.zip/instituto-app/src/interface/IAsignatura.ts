export interface IAsignatura {
  idasignatura: number;
  curso: string;
  nombre: string;
}