-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-01-2022 a las 12:56:40
-- Versión del servidor: 10.1.33-MariaDB
-- Versión de PHP: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria`
--
CREATE DATABASE IF NOT EXISTS `libreria` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `libreria`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

DROP TABLE IF EXISTS `libros`;
CREATE TABLE `libros` (
  `ISBN` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Titulo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Autor` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sinopsi` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Num. Paginas` int(11) NOT NULL,
  `seccion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`ISBN`, `Titulo`, `Autor`, `Sinopsi`, `Num. Paginas`, `seccion`) VALUES
('9788418173110', 'Harry Potter y el cáliz de fuego (4)', 'J. K. Rowling', 'Harry Potter y el cáliz de fuego es la cuarta entrega de la serie fantástica de la autora británica J.K. Rowling. «Habrá tres pruebas, espaciadas en el curso escolar,', 672, 'Juvenil'),
('9788418173134', ' Harry Potter y las reliquias de la muerte (7)', 'J. K. Rowling', 'Harry Potter y las reliquias de la muerte es el séptimo y último volumen de la ya clásica serie fantástica de la autora británica J.K. Rowling. «Entregadme a Harry Potter', 704, 'Juvenil'),
('9788445009949', 'La mano izquierda de la oscuridad', 'Le Guin, Ursula K.', '«La luz es la mano izquierda de la oscuridad, y la oscuridad es la mano derecha de la luz. Los dos son una, vida y muerte,', 336, 'Literatura'),
('9788445012093', 'Un mago de Terramar', 'Le Guin, Ursula K.', 'En el mundo de Terramar la magia es un elemento indispensable. Un principio fundamental rige ese mundo: el equilibrio entre la vida y la muerte, ', 264, 'Literatura'),
('9788466355469', 'El Instituto', 'Stephen King', '= SE RECLUTAN NIÑOS CON MENTES PRODIGIOSAS = La nueva e inquietante novela del maestro Stephen King. ', 624, 'Literatura'),
('9788466355810', 'La sangre manda', 'Stephen King', 'Cuatro novelas cortas de Stephen King sobre las fuerzas ocultas que nos acechan. En esta colección única nos ofrece un impactante noir paranormal, protagonizado por la carismática Holly Gibney, y tres relatos más que ponen de manifiesto el incomparab', 464, ''),
('9788466356770', 'La mitad oscura', 'Stephen King', 'Stephen King sorprende y aterroriza una vez más al lector con su magistral don para destapar y exhibir la mitad más oscura del ser humano. ', 568, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`username`, `password`, `role`) VALUES
('admin', 'admin', 'admin'),
('javier', 'javier', 'cliente'),
('juan', 'juan', 'librero'),
('laia', 'laia', 'librero'),
('laura', 'laura', 'cliente'),
('marta', 'marta', 'cliente'),
('yaiza', 'yaiza', 'cliente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`ISBN`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD KEY `username` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
