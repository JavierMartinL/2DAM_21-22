/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Modelo;
import vista.VistaPrincipal;

/**
 * Clase controlador encargada de: 
 * - recoger los eventos de partedelcliente
 * - solicitar y recibir la información del modelo
 * - mostrar las vistas adecuadas en cada momento y con los datos. 
 * @author laia
 */
public class Controlador implements ActionListener{
    
    
    private VistaPrincipal vistaPpl;
    private Modelo modelo;

    /***
     * Controlador encargado de asignar el escuchador a cada componente que 
     * disponga de uno
     * 
     * @param modelo  el objeto modelo de nuestra ejecución 
     * @param vistaPpl el objeto vista
     */
    public Controlador( Modelo modelo, VistaPrincipal vistaPpl ) {
        this.vistaPpl = vistaPpl;
        this.modelo = modelo;
        this.vistaPpl.jBSuma.addActionListener(this);
        this.vistaPpl.jBMult.addActionListener(this);
        this.vistaPpl.jBRest.addActionListener(this);
    }
    
    /***
     *  Encargada de modificar las caracteristicas adecuadas para inicial la 
     *  vista principal
     * 
     */
    public void iniciar(){
        vistaPpl.setTitle("Operacions_MVC");
        vistaPpl.setLocationRelativeTo(null);
        vistaPpl.setVisible(true);
    }
    
    /***
     * Sobreescribimos el método de la interfície ActionListener donde retoma la 
     * actividad despues de la realización de un evento
     * 
     * En este caso primero recogemos los valores de los dos operandos y 
     * posteriormente obtenemos el objeto "fuente" del evento que se ha realizado
     * y segun que componente(Objeto) se haya clicado se realizará una funcióno 
     * otra del modelo.
     * 
     * Finalmente se recoge el resultado y se le asigna al TextField 
     * 
     * @param e 
     */
    @Override
    public void actionPerformed(ActionEvent e) {
              
        
        modelo.setOperando1(Integer.parseInt(vistaPpl.jTFOp1.getText()));
        modelo.setOperando2(Integer.parseInt(vistaPpl.jTFOp2.getText()));
               
        Object oEvent = e.getSource();
        
        if(oEvent==vistaPpl.jBSuma){
            
            modelo.sumar();
            
        }else if(oEvent==vistaPpl.jBMult){
            
            modelo.multiplicar();
            
        }else if(oEvent==vistaPpl.jBRest){
            modelo.restar();
        //}else if(oEvent==vistaPpl.jBSuma){    
        }
        
        vistaPpl.jTFResult.setText(String.valueOf(modelo.getResultado()));
    }
    
}
