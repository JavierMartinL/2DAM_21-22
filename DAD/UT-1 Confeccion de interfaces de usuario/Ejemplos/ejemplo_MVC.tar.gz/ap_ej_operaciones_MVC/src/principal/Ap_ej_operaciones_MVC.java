/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import controlador.Controlador;
import modelo.Modelo;
import vista.VistaPrincipal;

/**
 *  Clase principal donde creamos una instancia de los objetos dela clase Modelo,
 * VistaPrincipal y Controlador.
 * 
 * Las instancias de Modelo y VistaPrincipal se pasan como parámetros al controlador 
 * en el constructor
 * 
 * @author laia
 */
public class Ap_ej_operaciones_MVC {

    /**
     * Creamos las instancias de las clases y modificamos las propiedadesde la 
     * vista "Principal" para que se muestre por pantalla
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        VistaPrincipal vistappl = new VistaPrincipal();
        Controlador controlador = new Controlador(modelo,vistappl);
        controlador.iniciar();
        
    }
    
}
