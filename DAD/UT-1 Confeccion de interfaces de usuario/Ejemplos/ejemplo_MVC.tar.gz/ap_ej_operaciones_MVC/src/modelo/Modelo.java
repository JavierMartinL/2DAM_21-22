/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *  Creamos un modelo de datos donde tenemos tres atributos, uno para cada 
 *  operando y resultado,  y los metodos necesarios para las operaciones que se 
 *  quieren implementar
 * 
 * @author laia
 */
public class Modelo {
    
    private int operando1;
    private int operando2;
    private int resultado;

    public int getOperando1() {
        return operando1;
    }

    public void setOperando1(int operando1) {
        this.operando1 = operando1;
    }

    public int getOperando2() {
        return operando2;
    }

    public void setOperando2(int operando2) {
        this.operando2 = operando2;
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }

    /***
     * Operación para sumar
     */      
    public void sumar(){
        
       this.resultado = this.operando1 + this.operando2;
       
    }
    /***
     * Operación para multiplicar
     */ 
    public void multiplicar(){
        
       this.resultado = this.operando1 * this.operando2;
        
    }
     /***
     * Operación para restar
     */ 
    public void restar() {
        this.resultado = this.operando1 - this.operando2;
    }
}
