﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicios_iniciales
{
    class SaleItem
    {
        private string _name;
        private decimal _cost;

        public SaleItem(string name, decimal cost)
        {
            _name = name;
            _cost = cost;
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                 if(value!="") _name = value;
            }
        }

        public decimal Price
        {
            get => _cost;
            set => _cost = value;
        }
    }


    /******
     * */

    public class SaleItem2
    {
        public string Name { get; set; }

        public decimal Cost { get; set; }
    }


    /*class Program
    {
       static void Main(string[] args)
       {
                      var item = new SaleItem("Shoes", 19.95m);
            Console.WriteLine($"{item.Name}: sells for {item.Price:C2}");
            //Falta probar de añadir un nuevo precio con set
            item.Name = "Shoes2";
            item.Price = 13.234m;
            Console.WriteLine($"item->{item.Name}: sells for {item.Price:C2}");

            var item2 = new SaleItem2();
            item2.Name = "car";
            item2.Cost = 200.123m;
            Console.WriteLine($"item2->{item2.Name}: sells for {item2.Cost:C2}");

            var item3 = new SaleItem2 { Name = "banana", Cost = 2.123m };
            Console.WriteLine($"item3->{item3.Name}: sells for {item3.Cost:C2}");
       }
    }*/
}