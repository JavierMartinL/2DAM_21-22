﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicios_iniciales
{
    partial class Metodos
    {

        /****
        * 
        * 9.- Crear un array de 20 números aleatorios enteros aleatorios entre 10 y 20. 
        * Para cada elemento, informar si es la primera vez que aparece, o si se trata de un 
        * elemento repetido y nos indique cuántas veces había aparecido con anterioridad.
        * 
        * */
        public static void AleatoriosRepetidos(string v)
        {
            
            //genero el array random
            var rand = new Random();
            int[] valores = new int[10];
            Console.WriteLine("Five random integers between 50 and 100:");
            for (int ctr = 0; ctr < 10; ctr++)
            {
                valores[ctr] = rand.Next(10, 20);
                Console.Write("{0}-", valores[ctr]);
            }
            Console.WriteLine();
            Dictionary<int, int> elementos = new Dictionary<int, int>();
            elementos = repetidos_dic(valores);

            foreach (KeyValuePair<int, int> kvp in elementos)
            {
                Console.WriteLine("el elemento  {0}, aparece {1} {2}",
                    kvp.Key, kvp.Value, kvp.Value > 1 ? "veces" : "vez");
            }
           

            //Con Table Hash
            Hashtable elem_hash = new Hashtable();
            elem_hash = repetidos_hash(valores);
            foreach (DictionaryEntry de in elem_hash)
            {
                Console.WriteLine("el elemento  {0}, aparece {1} {2} Con HashTable",
                    de.Key, de.Value, (int)de.Value > 1 ? "veces" : "vez");
            }
            

        }

        public static Dictionary<int, int> repetidos_dic(int[] array)
        {

            Dictionary<int, int> elementos = new Dictionary<int, int>();
            // int[] array = { 3, 4, 5, 6 };

            foreach (int elemento in array)
            {
                //elementos.Add(elemento, 1);
                if (!elementos.ContainsKey(elemento))
                {
                    elementos[elemento] = 1;
                }
                else
                {
                    elementos[elemento] += 1;
                }

            }

            return elementos;

        }
        public static Hashtable repetidos_hash(int[] array)
        {

            Hashtable elementos = new Hashtable();
           

            foreach (int elemento in array)
            {
                //elementos.Add(elemento, 1);
                if (!elementos.ContainsKey(elemento))
                {

                    elementos[elemento] = 1;
                }
                else
                {
                    elementos[elemento] = (int)elementos[elemento] + 1;
                    //elementos[elemento];
                }

            }

            return elementos;

        }


        public static void GestionFichero()
        {


            string opcion = mostrar_menu();
            string texto_modificado = "";
            while (opcion != "s")
            {

                string path = @"ejemplo.txt";
                try
                {
                    // This text is added only once to the file.

                    switch (opcion)
                    {
                        case "m":
                            string readText = File.ReadAllText(path);
                            Console.WriteLine("El archivo tiene: ");
                            Console.WriteLine(readText);
                            break;

                        case "a":
                            // Añadir un texto al final del archivo.
                            string texto = "Añadir texto al final del archivo" + Environment.NewLine;
                            File.AppendAllText(path, texto, Encoding.UTF8);

                            break;

                        case "b":

                            Console.WriteLine("Que palabra quieres borrar: ");

                            string palabra = Console.ReadLine();
                            using (StreamReader sr = new StreamReader(path))
                            {

                                string line;
                                while ((line = sr.ReadLine()) != null)
                                {
                                    texto_modificado += line.Replace(palabra, "") + "\n";

                                }
                                Console.WriteLine("El texto_modificado: ");
                                Console.WriteLine(texto_modificado);
                            }


                            break;

                        case "g":
                            // Guardar el archivo

                            File.WriteAllText(path, texto_modificado);

                            break;

                        default:
                            Console.WriteLine("La letra que has indicado no es valida");
                            break;
                    }
                    /*string readText2 = File.ReadAllText(path);
                    Console.WriteLine("El archivo FIN: ");
                    Console.WriteLine(readText2);*/

                }

                catch (Exception e)
                {
                    // Expliquemos al usuario que ha ido mal.
                    Console.WriteLine("El fichero no se ha podido leer:");
                    Console.WriteLine(e.Message);
                }
                opcion = mostrar_menu();
            }
            // --------------------  ;


        }

        public static string mostrar_menu()
        {
            Console.WriteLine("Escoge una opcion del menú para ficheros: ");
            Console.WriteLine("• (m)Mostrar el archivo ");
            Console.WriteLine("• (a)Añadir un texto al final del archivo ");
            Console.WriteLine("• (b)Borrar una palabra ");
            Console.WriteLine("• (g)Guardar el archivo ");
            Console.WriteLine("• (s)Salir ");

            return Console.ReadLine();
        }

    }
}
