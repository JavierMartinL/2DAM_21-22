﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Ejercicios_iniciales
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Qué ejercicio quieres hacer[4,5,7,8,9,11, 0(para salir)]: ");
            int ejercicio = int.Parse(Console.ReadLine());
            while (ejercicio != 0)
            {
                switch (ejercicio)
                {
                    case 4:
                        /***
                         *
                         * 4.- iterativas Pide al usuario 2 valores numéricos, e indica cuál es 
                         * más grande de los dos. Si son iguales indicarlo también.
                         * 
                         * */
                        Metodos.BuscarMayor();
                        break;

                    case 5:
                        /**
                        * 
                        * 5.- bucles Lee un número por teclado e indica si es divisible entre 2 
                        * (resto = 0). Si no lo es, también debemos indicarlo. En caso afirmativo 
                        * que calcule el factorial (n * (n-1) * ... * 1)
                        * 
                        */
                        Metodos.NumeroParFactorial();
                        break;

                    case 7:
                        /*
                        * 7.- iterativas y bucles Desarrollar un programa para jugar a 
                        * "Adivina el número". Se parte de un número entero positivo previamente 
                        * determinado (por ejemplo 15).
                        * Se pide al usuario que introduzca un valor numérico. 
                        * Si el dato introducido por el usuario coincide con el almacenado, el 
                        * juego termina. Si el dato introducido por el usuario es menor 
                        * (respectivamente mayor) que el almacenado, se indica esta situación 
                        * al usuario y se le vuelve a pedir que introduzca otro número. El juego 
                        * termina cuando el usuario acierta o si llega a las 5 oportunidades.
                        */
                        Metodos.AdivinarNumero();
                        break;

                    case 8:
                        /*
                        * 8.- iterativas, tratamientos de errores, funciones: 
                        * Aplicación de calculadora que muestre un menú con las opciones sumar, 
                        * restar, multiplicar, dividir y salir. 
                        * A continuación pida dos números, y los opere
                        * */
                        Console.WriteLine(" la quieres normal (0) o con clases(1): ");
                        int tipoCalc = int.Parse(Console.ReadLine());
                        Metodos.Calculadora(tipoCalc);

                        break;

                    case 9:

                        /****
                        * 
                        * 9.- Crear un array de 20 números aleatorios enteros aleatorios entre 10 y 20. 
                        * Para cada elemento, informar si es la primera vez que aparece, o si se trata de un 
                        * elemento repetido y nos indique cuántas veces había aparecido con anterioridad.
                        * 
                        * */
                        Metodos.AleatoriosRepetidos("Dictionary");

                        break;

                    case 11:

                        /***
                         *  11.- Fichero: Crea un programa que nos dejará realizar diferentes acciones a escoger en menú siguiente
                         *      •  Mostrar el archivo
                         *      •  Añadir un texto al final del archivo
                         *      •  Borrar una palabra y nos devolverá el texto de nuevo pero sin la palabra escogida
                         *      •  Guardar el archivo con el mismo nombre
                         *      •  Salir
                         *      
                         *      */

                        Metodos.GestionFichero();
                        break;



                    default:
                        Console.WriteLine("Este ejercicio no está.");
                        break;


                }
                Console.WriteLine("Que ejercicio quieres hacer: ");
                ejercicio = int.Parse(Console.ReadLine());


            }
            var item = new SaleItem("Shoes", 19.955m);
            Console.WriteLine($"item -> {item.Name}: sells for {item.Price:C2}");
            //Falta probar de añadir un nuevo precio con set
            item.Name = "Shoes2";
            item.Price = 13.234m;
            Console.WriteLine($"item cambiado->{item.Name}: sells for {item.Price:C2}");

            var item2 = new SaleItem2();
            item2.Name = "car";
            item2.Cost = 200.123m;
            Console.WriteLine($"item2->{item2.Name}: sells for {item2.Cost:C2}");

            var item3 = new SaleItem2 { Name = "banana", Cost = 2.123m };
            Console.WriteLine($"item3->{item3.Name}: sells for {item3.Cost:C2}");


        }
    }
}
