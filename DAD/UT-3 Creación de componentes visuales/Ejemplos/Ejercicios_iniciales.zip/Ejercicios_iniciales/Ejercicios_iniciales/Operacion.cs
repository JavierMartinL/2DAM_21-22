﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicios_iniciales
{
	public class Operacion
	{
		//atributos
		private string _nombreOp;
		private int _res;

		//propiedad
		public string NombreOp {
			get
			{
				return _nombreOp;
			}
			set
			{
				_nombreOp = value;
			}
		}

		public int getRes()
        {
			return _res;
        }

		public void setRes(int valor)
		{
			_res = valor;
		}
		//public int Res { get => _res; set => _res = value; }

		//constructores
		public Operacion()
		{

		}
		public Operacion(string operacio, int operand1, int operand2)
		{
			switch (operacio)
			{
				case "s":
					this.NombreOp = "suma";
					this.setRes(operand1 + operand2);
					break;
				case "r":
					this.NombreOp = "resta";
					//this.Res = operand1 - operand2;
					break;
				case "m":
					this.NombreOp = "multiplicación";
					//this.Res = operand1 * operand2;
					break;
				case "d":
					this.NombreOp = "división";
					//this.Res = operand1 - operand2;
					break;
				default:
					Console.WriteLine("Alguna cosa ha ido mal");
					break;
			}
		}
		


	}
}
