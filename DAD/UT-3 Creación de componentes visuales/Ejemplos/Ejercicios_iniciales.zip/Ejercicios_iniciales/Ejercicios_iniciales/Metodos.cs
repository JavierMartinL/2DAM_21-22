﻿using System;
using System.Collections.Generic;


namespace Ejercicios_iniciales
{
    partial class Metodos
    {
        /***
        *
        * 4.- iterativas Pide al usuario 2 valores numéricos, e 
        * indica cuál es más grande de los dos. Si son iguales 
        * indicarlo también.
        * 
        * */

        public static void BuscarMayor()
        {

            Console.WriteLine("Dame dos numeros - ");
            int primero = -1;
            int segundo = -1;
            string valor = "";
            while (primero == -1 || segundo == -1)
            {
                try
                {
                    if (primero == -1)
                    {
                        Console.WriteLine("El primero:");
                        valor = Console.ReadLine();
                        primero = Int32.Parse(valor);
                    }
                    Console.WriteLine("El segundo:");
                    valor = Console.ReadLine();
                    segundo = Int32.Parse(valor);
                }
                catch (FormatException)
                {
                    Console.WriteLine("no ha sido posible parsear '{0}'.", valor);
                }
                catch (OverflowException)
                {
                    Console.WriteLine("'{0}' está fuera de rango Int32 type.", valor);
                }

            }
            int mayor = 0;

            if (primero == segundo) Console.WriteLine("Los dos valores son iguales ");
            else
            {
                if (primero > segundo) mayor = primero;
                else mayor = segundo;
                Console.WriteLine("EL mayor valor es: " + mayor);
            }
        }

        /*****************************
        * 5.- bucles Lee un número por teclado e indica si es 
        * divisible entre 2 (resto = 0). Si no lo es, también 
        * debemos indicarlo. En caso afirmativo que calcule el 
        * factorial (n * (n-1) * ... * 1)
        * 
        */
        public static void NumeroParFactorial()
        {
            
            int factor = -1;
            while (factor == -1)
            {
                try
                {
                    if (factor == -1)
                    {
                        Console.WriteLine("Escribe un número: ");
                        factor = Int32.Parse(Console.ReadLine());
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Vigila que lo que me estas dando sea un número: " + ex.Message);
                }
                int result = factor;
                if ((factor % 2) == 0)
                {
                    while
                        (factor > 1)
                    {
                        factor--;
                        result = result * factor;
                    }
                    Console.WriteLine("El factor es:" + result);
                }
                else Console.WriteLine("no es numero parell");
            }
        }


        /*
        * 7.- iterativas y bucles Desarrollar un programa para 
        * jugar a "Adivina el número". Se parte de un número 
        * entero positivo previamente determinado (por ejemplo 15).
        * Se pide al usuario que introduzca un valor numérico. 
        * Si el dato introducido por el usuario coincide con el 
        * almacenado, el juego termina. Si el dato introducido 
        * por el usuario es menor (respectivamente mayor) que el 
        * almacenado, se indica esta situación al usuario y se le 
        * vuelve a pedir que introduzca otro número. El juego 
        * termina cuando el usuario acierta o si llega a las 5 
        * oportunidades.
        */
        public static void AdivinarNumero()
        {

            Console.WriteLine("Vamos a adivinar el numero, tienes 5 intentos");
            int num = 0;
            int oportunitats = 5;
            int adivina = 23;


            while (num != adivina && oportunitats > 0)
            {
                try
                {
                    num = int.Parse(Console.ReadLine());
                    if (num < adivina) Console.WriteLine("tu numero: {0} , es mas pequeño que el que tienes que adivinar", num);
                    else if (num > adivina) Console.WriteLine("tu numero: {0} , es mas grande que el que tienes que adivinar", num);
                    else Console.WriteLine("Correcte!!!  {0} , es el número, lo has adivinado", num);
                    oportunitats--;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Vigila que lo que me estas dando sea un número: " + ex.Message);
                }
                if (oportunitats == 0) Console.WriteLine("Has agotado todos los intentos", num);
            }
        }


        /*
        * 8.- iterativas, tratamientos de errores, funciones 
        * Aplicación de calculadora que muestre un menú con las 
        * opciones sumar, restar, multiplicar, dividir y salir. 
        * A continuación pida dos números, y los opere
        * */
        public static void Calculadora(int tipoCalc)
        {

            Console.WriteLine("Vamos OPERAR, escull una operació:");
            Console.WriteLine("s = Sumar.");
            Console.WriteLine("r = Restar.");
            Console.WriteLine("m = Multiplicar.");
            Console.WriteLine("d = Dividir.");
            Console.WriteLine("0 = Para Salir.");
            int fin = 3;
            string operacion = "";
            string entrada = "";
            int op1 = 0;
            int op2 = 0;
            int resu = 0;
            //string nom_operación = "";
            while (fin > 0)
            {
                try
                {
                    entrada = Console.ReadLine();

                    if (fin == 3)
                    {
                        if (entrada == "s" || entrada == "r" || entrada == "m" || entrada == "d")
                        {
                            operacion = entrada;
                            fin--;
                            Console.WriteLine("Ahora escribe el primer operando:");
                        }
                        else Console.WriteLine("Vuelve a escribi la operación que sea valida:");
                    }
                    else if (fin == 2)
                    {
                        op1 = int.Parse(entrada);
                        fin--;
                        Console.WriteLine("Escribe el segundo operando:");
                    }
                    else if (fin == 1)
                    {
                        op2 = int.Parse(entrada);
                        fin--;
                    }
                    else if (int.Parse(entrada) == 0)
                    {
                        Console.WriteLine("Adios!");
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Volvamos a empezar");
                        fin = 3;

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Vigila que el parametro no es correcto, hazlo otra vez " + ex.Message);
                }

            }

            if (tipoCalc == 0)
            {
                switch (operacion)
                {
                    case "s":
                        resu = op1 + op2;
                        break;
                    case "r":
                        resu = op1 - op2;
                        break;
                    case "m":
                        resu = op1 * op2;
                        break;
                    case "d":
                        resu = op1 / op2;
                        break;
                }

                Console.WriteLine("------------------------------------------------------ ");
                Console.WriteLine("El resultado de la {0} es: {1}", operacion, resu);

            }
            else
            {
                // Con clases
                Operacion opera = new Operacion(operacion, op1, op2);


                Console.WriteLine("------------------------------------------------------ ");
                Console.WriteLine("El resultado de la {0} es: {1}", opera.NombreOp, opera.getRes());

            }
        }



    }
}
