-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-04-2018 a las 14:28:45
-- Versión del servidor: 10.1.16-MariaDB
-- Versión de PHP: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `shop`
--
CREATE DATABASE IF NOT EXISTS `shop` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
USE `shop`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `basket`
--

DROP TABLE IF EXISTS `basket`;
CREATE TABLE IF NOT EXISTS `basket` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `total` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `basket`
--

INSERT INTO `basket` (`id`, `name`, `total`) VALUES
(12345678, 'Jeans1', 52.68);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id_category` int(11) NOT NULL,
  `description` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id_category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id_category`, `description`) VALUES
(1, 'woman'),
(2, 'man'),
(3, 'kids'),
(4, 'news');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catman`
--

DROP TABLE IF EXISTS `catman`;
CREATE TABLE IF NOT EXISTS `catman` (
  `id` int(8) NOT NULL,
  `name` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `category` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `catman`
--

INSERT INTO `catman` (`id`, `name`, `category`, `description`, `price`, `quantity`) VALUES
(12345670, 'Shirts2', 'Shirts', 'Es un shirt espectacular', 15, 10),
(12345671, 'T-shirts1', 'T-shirts', 'Es un T-shirt espectacular', 9, 24),
(12345672, 'Shirts3', 'Shirts', 'Es un shirt espectacular', 29.99, 30),
(12345673, 'Shirts4', 'Shirts', 'Es un shirt espectacular', 19.95, 4),
(12345674, 'Jeans3', 'Jeans', 'Es un jean espectacular', 56.34, 1),
(12345675, 'Jeans2', 'Jeans', 'Es un jean espectacular', 56.99, 14),
(12345676, 'T-shirts2', 'T-shirts', 'Es un T-shirt espectacular', 2, 2),
(12345678, 'Jeans1', 'Jeans', 'Es un jean espectacular', 26.34, 2),
(12345679, 'Shirts1', 'Shirts', 'Es un shirt espectacular', 18, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id_staff` int(10) NOT NULL,
  `password` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `role` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id_staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id_staff`, `password`, `role`) VALUES
(12345678, 'pruebas', 'basic'),
(12345679, 'manager', 'admin'),
(20158212, 'mVargas3', 'admin'),
(20171248, 'pGracia1', 'basic');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
