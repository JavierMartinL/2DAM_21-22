﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_binding_controls
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public uniontextos unimosNombreApellido;
        public MainWindow()
        {
            InitializeComponent();

            notificarCambioPropiedades();

            mostrarVariableEnControl();
            
           
        }

        private void notificarCambioPropiedades()
        {
            unimosNombreApellido = new uniontextos();
            unimosNombreApellido.Nombre = "Laia";
            unimosNombreApellido.Apellido = "Romeo";
            this.DataContext = unimosNombreApellido;
        }

        private void mostrarVariableEnControl()
        {
            List<poblacion> poblaciones = new List<poblacion>();
            poblaciones.Add(new poblacion(1,"Puerto de la Cruz"));
            poblaciones.Add(new poblacion(2, "Santa Cruz de Tenerife"));
            poblaciones.Add(new poblacion(3, "La Oritava"));
            poblaciones.Add(new poblacion(4, "Santa Cruz de la Palma"));
            EjemplolListBox.ItemsSource = poblaciones;
        }

        private void mostrarItem(object sender, SelectionChangedEventArgs e)
        {
            poblacion lbi = ((sender as ListBox).SelectedItem as poblacion);
            Itemtext.Content = "   Item seleccionado " + lbi.Id +" - "+ lbi.Nombre + ".";
        }
    
    }
}
