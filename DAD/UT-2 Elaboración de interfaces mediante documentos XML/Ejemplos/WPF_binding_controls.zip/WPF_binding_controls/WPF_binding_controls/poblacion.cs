﻿namespace WPF_binding_controls
{
    internal class poblacion
    {
        int id;
        string nombre;

        public poblacion(int id, string nombre)
        {
            this.Id = id;
            this.Nombre = nombre;
        }

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
    }
}