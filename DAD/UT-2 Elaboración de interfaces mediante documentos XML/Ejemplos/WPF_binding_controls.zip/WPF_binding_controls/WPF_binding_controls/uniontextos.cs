﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_binding_controls
{
    public class uniontextos : INotifyPropertyChanged
    {

        private string nombre, apellido, union_textos;

        //Evento que se desencadena cuando se cambia una propiedad en un componente
        public event PropertyChangedEventHandler PropertyChanged;

        //Metodo que le lanza cada vez que cambia un a propiedad ( texto, color de fondo, borde,...)
        private void OnPropertyChange(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        public string Nombre
        {
            get { return nombre; }
            set { 
                nombre = value;
                //llamamos a este metodo cuando queremos lanzar un cambio en la propiedad 'UnionTectos' 
                OnPropertyChange("UnionTextos");
            }
        }
        public string Apellido
        {
            get { return apellido; }
            set { 
                apellido = value;
                OnPropertyChange("UnionTextos");
            }
        }
        public string UnionTextos
        {
            get {
                union_textos = nombre + " " + apellido;
                return union_textos; }
            set { nombre = value; }
        }
    }
}
